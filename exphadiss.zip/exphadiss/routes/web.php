<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\BaseController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\MailController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [BaseController::class,'index']);

Route::get('/matricula', [BaseController::class,'matricula']);
Route::post('/matricula', [BaseController::class,'matricula']);

Route::get('/gracias', [BaseController::class,'gracias']);

Route::get('/signin', [BaseController::class,'login']);
Route::post('/signin', [BaseController::class,'login']);
Route::get('/logout', [BaseController::class,'logout']);



Route::get('/admin', [AdminController::class,'admin']);
Route::post('/admin', [AdminController::class,'admin']);

Route::get('/horariowp', [AdminController::class,'horariowp']);
Route::post('/horariowp', [AdminController::class,'horariowp']);

Route::get('/menuwp', [AdminController::class,'menuwp']);
Route::post('/menuwp', [AdminController::class,'menuwp']);


Route::get('/bannerwp', [AdminController::class,'bannerwp']);
Route::post('/bannerwp', [AdminController::class,'bannerwp']);

Route::get('/nosotroswp', [AdminController::class,'nosotroswp']);
Route::post('/nosotroswp', [AdminController::class,'nosotroswp']);
Auth::routes();

Route::get('/pilareswp', [AdminController::class,'pilareswp']);
Route::post('/pilareswp', [AdminController::class,'pilareswp']);

Route::get('/propuestawp', [AdminController::class,'propuestawp']);
Route::post('/propuestawp', [AdminController::class,'propuestawp']);

Route::get('/galeria', [AdminController::class,'galeria']);
Route::post('/galeria', [AdminController::class,'galeria']);


Route::get('/googlemaps', [AdminController::class,'googlemaps']);
Route::post('/googlemaps', [AdminController::class,'googlemaps']);

Route::get('/anuncioswp', [AdminController::class,'anuncioswp']);
Route::post('/anuncioswp', [AdminController::class,'anuncioswp']);

Route::get('/contacto', [AdminController::class,'contacto']);
Route::post('/contacto', [AdminController::class,'contacto']);

Route::get('/redes', [AdminController::class,'redes']);
Route::post('/redes', [AdminController::class,'redes']);

Route::get('/profile', [AdminController::class,'profile']);
Route::post('/profile', [AdminController::class,'profile']);
/*==============================================================*/

Route::get('/menuwm', [AdminController::class,'menuwm']);
Route::post('/menuwm', [AdminController::class,'menuwm']);

Route::get('/bannerwm', [AdminController::class,'bannerwm']);
Route::post('/bannerwm', [AdminController::class,'bannerwm']);

Route::get('/matriculawm', [AdminController::class,'matriculawm']);
Route::post('/matriculawm', [AdminController::class,'matriculawm']);

Route::get('/formulariowm', [AdminController::class,'formulariowm']);
Route::post('/formulariowm', [AdminController::class,'formulariowm']);

/*==================================================================*/
Route::get('/insertarpropuesta', [AdminController::class,'insertarpropuesta']);

Route::get('/galeriafotos', [AdminController::class,'galeriafotos']);
Route::post('/galeriafotos', [AdminController::class,'galeriafotos']);
/*==================================================================*/

Route::get('/ajax/loadimg', [AdminController::class,'subirimg']);

/*==================================================================*/

Route::get('/subirimagen', [AdminController::class,'subirimagen']);
Route::get('/eliminarImagen', [AdminController::class,'Elimng']);

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::get('/changetype', [AdminController::class,'changetype']);
