@extends('base')
@section('content')
                    <div class="card">
                        <form method="post">
                            <div class="card-body p-1">
                                <div class="container-fluid">
                                    <div class="form-group">
                                        @csrf
                                        <button class="button_editar" style="display: block;position:absolute;right: 6.9rem;top: 1rem;" type="submit">Guardar</button>
                                        <button class="button_editar button-right agregarnuevaseccion" type="button">Agregar</button>
                                        <h4 class="control-label">Galeria</h4>
                                    </div>
                                    <hr class="mt-2">
                                    <div class="row">

                                        <div class="col-md-12 mb-4">
                                            <div class="card h-100 p-1 shadow">
                                                <div class="card-body">
                                                    <h4 class="text-inherit">Titulo</h4>
                                                    <input type="text" class="form-control" value="@if($titulo){{$titulo}}@endif" name="title_galeria_exphadis" placeholder="Eventos Exphadis">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row contenerdorfachero">

                                            

                                        </div>

                                        

                                    </div>
                                </div>
                            </div>
                            <input class="dataval" type="hidden" name="data" value='{{$data}}'>
                        </form>
                    </div>
<script>
    const contenedor = document.querySelector('.contenerdorfachero');
    const input = document.querySelector('.dataval');
    const agregadorasd = document.querySelector('.agregarnuevaseccion');
    let lista = [];

    function parser(){
        lista = JSON.parse(input.value); 
    }


    window.galupdate = galupdate;

    parser();

    agregadorasd.addEventListener('click',()=>{
        lista.push({titulo:'Nueva Sección', visible:false, imgs:[]});
        window.galupdate();
    })




    function render(){
        contenedor.innerHTML = '';
        lista.map((el,index)=>{
            contenedor.innerHTML += `
            
            <div class="col-lg-6 mb-4">
                    <div class="card h-100 p-1 shadow">
                        <div class="card-body">
                            <div class="form-group">
                                <div class="mb-1">
                                    <input class="control-label form-control w-50 text-inherit titleedit" data-index="${index}" value="${el.titulo}" type="text">
                                </div>
                                <div class="button-right">
                                    <h4>Visible </h4>
                                    <div class="switch">
                                        <input type="checkbox" class="checkkk" data-index="${index}"  ${el.visible?'checked':''} />
                                        <div></div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="container-fluid">
                                    <div class="row">
                                    ${ 
                                        (()=>{
                                            let res = '';
                                        el.imgs.map((link,ind)=>{
                                            res+=`
                                        <div class="col-xl-4 col-lg-6">
                                            <img class="img-fluid-2 bc-img-2 bc-default hero__cta imggg imggal${index}${ind}" data-galery="true" data-index="${index}" data-img="${ind}" src="${link}"><span data-galery="true" data-index="${index}" data-img="${ind}" class="ll delete_img">X</span>
                                        </div>
                                        `})
                                        return res;
                                        })()
                                    }
                                        <a href="javascript:void(0);" class="button_editar btnagg mt-1 w-100 text-center" data-index="${index}" type="submit">Agregar Imagen</a>
                                        <a href="javascript:void(0);" class="button_editar btnaee mt-1 w-100 text-center" data-index="${index}" type="submit">Eliminar Sección</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            `;
        })
    }

    function saver(){
        input.value = JSON.stringify(lista);
    }

    function aggrer(){
        
        Object.values(document.querySelectorAll('.btnaee')).map(el=>{
            el.addEventListener('click',async(e)=>{
                let  res  = await swal("¿Desea Eliminar esta Seccion?", {
                    icon: "warning" ,
                    dangerMode: true,
                    buttons: true,
                });
                if(res){
                    let semi = [];
                    lista.map((ff,index)=>{
                        if(index!=parseInt(e.target.dataset.index)){
                            semi.push(ff);
                        }
                    });
                    lista = semi;
                    window.galupdate({eli:true});
             }
            });
        });

        Object.values(document.querySelectorAll('.btnagg')).map(el=>{
            el.addEventListener('click',(e)=>{
                lista[e.target.dataset.index].imgs.push('nuevaIMG');
                window.galupdate();
            });


        })
    }

    function titler(){
       
        Object.values(document.querySelectorAll('.titleedit')).map(el=>{
            el.addEventListener('change',(e)=>{
                lista[e.target.dataset.index].titulo = e.target.value;
                window.galupdate();
            });
        })
    }

    function checkers(){
        Object.values(document.querySelectorAll('.checkkk')).map(el=>{
            el.addEventListener('change',(e)=>{
                lista[e.target.dataset.index].visible = e.target.checked;
                window.galupdate();
            })
        })
    }

    function imaginazer(){
        Object.values(document.querySelectorAll('.imggg')).map((el)=>{
            lista[el.dataset.index].imgs[el.dataset.img] = el.src;
        });
 
    }

    function galupdate(dat={}){
        if(!dat.eli)imaginazer();
        saver();
        parser();
        render();
        trashListener();
        aggrer();
        checkers();
        titler();
        window.loadmodales();
        
    }

    function trashListener(){
        
        //eliminar foto
        Object.values(document.querySelectorAll('.ll')).map(el=>
            el.addEventListener('click',async(e)=>{
                e.preventDefault();
                let  res  = await swal("¿Desea Eliminar esta foto?", {
                    icon: "warning" ,
                    dangerMode: true,
                    buttons: true,
                });

                if(res){
                    let data = e.target.dataset;
                    let semiimgs = [];
                    lista[data.index].imgs.map((img,index)=>{
                        if(index!=data.img){
                            semiimgs.push(img);
                        }
                    });

                    lista[data.index].imgs = semiimgs;
                    window.galupdate({eli:true});

                }
            })
        );

    }

    
    render();
    trashListener();
    aggrer();
    checkers();
    titler();


</script>
@endsection