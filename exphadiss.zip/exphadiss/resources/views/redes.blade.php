@extends('base')
@section('content')
<form method="post">
                    <div class="card container-fluid">
                        <div class="card-body p-1">
                            <h4 for="" class="text-inherit">Redes Sociales</h4>
                                     @csrf
                                    <button class="button_editar button-right" type="submit">Guardar</button>
                            <hr class="mt-2 mb-2">
                                <div class="container-fluid">
                                    <div class="row">
                                    
                                        <div class="col-xl-4 col-lg-6 mb-4">
                                            <div class="card h-100 p-2 shadow">

                                                <div class="content-buttons-general-text mb-1">
                                                    <h4 class="text-inherit">WhatsApp Link</h4>
                                                    <div class="button-right-2">
                                                        <h4>Visible</h4>
                                                        <div class="switch">
                                                            <input type="checkbox" value="a" @if(count($data)>1)@if($data[0]->bool) checked @endif @endif name="redescheck" />
                                                            <div></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <input type="text" value="@if(count($data)>1){{$data[0]->link_redes}}@endif" name="link_redes_w" class="form-control">
                                                <input type="hidden" name="class_w" value="@if(count($data)>1){{$data[0]->clase}}@endif">
                                                <input type="hidden" name="class_w1" value="@if(count($data)>1){{$data[0]->clase1}}@endif">
                                                <input type="hidden" name="class_w2" value="@if(count($data)>1){{$data[0]->clase2}}@endif">
                                            </div>
                                        </div>
                                        <div class="col-xl-4 col-lg-6 mb-4">
                                            <div class="card h-100 p-2 shadow">
                                            <h4 class="text-inherit"></h4>

                                                <div class="content-buttons-general-text mb-1">
                                                    <h4 class="text-inherit">Facebook Link</h4>
                                                    <div class="button-right-2">
                                                        <h4>Visible</h4>
                                                        <div class="switch">
                                                            <input type="checkbox" value="b" @if(count($data)>2)@if($data[1]->bool) checked @endif @endif name="redescheck1" />
                                                            <div></div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <input type="text" value="@if(count($data)>2){{$data[1]->link_redes}}@endif" name="link_redes_f" class="form-control">
                                                <input type="hidden" name="class_f" value="@if(count($data)>2){{$data[1]->clase}}@endif">
                                                <input type="hidden" name="class_f1" value="@if(count($data)>2){{$data[1]->clase1}}@endif">
                                                <input type="hidden" name="class_f2" value="@if(count($data)>2){{$data[1]->clase2}}@endif">
                                            </div>
                                        </div>
                                        
                                        <div class="col-xl-4 col-lg-6 mb-4">
                                            <div class="card h-100 p-2 shadow">

                                                <div class="content-buttons-general-text mb-1">
                                                    <h4 class="text-inherit">Messenger Link</h4>
                                                    <div class="button-right-2">
                                                        <h4>Visible</h4>
                                                        <div class="switch">
                                                            <input type="checkbox" value="c" @if(count($data)>3)@if($data[2]->bool) checked @endif @endif name="redescheck2" />
                                                            <div></div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <input type="text"  value="@if(count($data)>3){{$data[2]->link_redes}}@endif" class="form-control" name="link_redes_m">
                                                <input type="hidden" name="class_m" value="@if(count($data)>3){{$data[2]->clase}}@endif">
                                                <input type="hidden" name="class_m1" value="@if(count($data)>3){{$data[2]->clase1}}@endif">
                                                <input type="hidden" name="class_m2" value="@if(count($data)>3){{$data[2]->clase2}}@endif">
                                            </div>
                                        </div>

                                        <div class="col-xl-4 col-lg-6 mb-4">
                                            <div class="card h-100 p-2 shadow">

                                                <div class="content-buttons-general-text mb-1">
                                                    <h4 class="text-inherit">Instagram Link</h4>
                                                    <div class="button-right-2">
                                                        <h4>Visible</h4>
                                                        <div class="switch">
                                                            <input type="checkbox" value="d" @if(count($data)>4)@if($data[3]->bool) checked @endif @endif name="redescheck3" />
                                                            <div></div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <input type="text" value="@if(count($data)>4){{$data[3]->link_redes}}@endif" class="form-control" id="" name="link_redes_i">
                                                <input type="hidden" name="class_i" value="@if(count($data)>4){{$data[3]->clase}}@endif">
                                                <input type="hidden" name="class_i1" value="@if(count($data)>4){{$data[3]->clase1}}@endif">
                                                <input type="hidden" name="class_i2" value="@if(count($data)>4){{$data[3]->clase2}}@endif">

                                            </div>
                                        </div>

                                        <div class="col-xl-4 col-lg-6 mb-4">
                                            <div class="card h-100 p-2 shadow">

                                                <div class="content-buttons-general-text mb-1">
                                                        <h4 class="text-inherit">YouTube Link</h4>
                                                    <div class="button-right-2">
                                                        <h4>Visible</h4>
                                                        <div class="switch">
                                                            <input type="checkbox" value="e" @if(count($data)>5)@if($data[4]->bool) checked @endif @endif name="redescheck4" />
                                                            <div></div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <input type="text"  value="@if(count($data)>5){{$data[4]->link_redes}}@endif" class="form-control" name="link_redes_y">  
                                                <input type="hidden" name="class_y" value="@if(count($data)>5){{$data[4]->clase}}@endif">
                                                <input type="hidden" name="class_y1" value="@if(count($data)>5){{$data[4]->clase1}}@endif">
                                                <input type="hidden" name="class_y2" value="@if(count($data)>5){{$data[4]->clase2}}@endif">
                                            </div>
                                        </div>

                                        <div class="col-xl-4 col-lg-6 mb-4">
                                            <div class="card h-100 p-2 shadow">

                                                <div class="content-buttons-general-text mb-1">
                                                        <h4 class="text-inherit">Gmail Link</h4>
                                                    <div class="button-right-2">
                                                        <h4>Visible</h4>
                                                        <div class="switch">
                                                            <input type="checkbox" value="f" @if(count($data)>5)@if($data[5]->bool) checked @endif @endif  name="redescheck5" />
                                                                <div></div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <input type="text"  value="@if(count($data)>5){{$data[5]->link_redes}}@endif" class="form-control" name="link_redes_g">  
                                                <input type="hidden" name="class_g" value="@if(count($data)>5){{$data[5]->clase}}@endif">
                                                <input type="hidden" name="class_g1" value="@if(count($data)>5){{$data[5]->clase1}}@endif">
                                                <input type="hidden" name="class_g2" value="@if(count($data)>5){{$data[5]->clase2}}@endif">
                                            </div>
                                        </div>
                                        
                                    </div>
                                </div>
                            
                        </div>
                    </div>
</form>
@endsection