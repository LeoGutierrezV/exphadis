@extends('base')
@section('content')
                    <div class="card">
                        <form method="post">
                            <div class="card-body p-4">
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="col-lg-6 col-12 mb-4">
                                            <div class="card h-100 p-1 shadow">
                                                <div class="form-group mt-1">
                                                    <label class="control-label">Titulo Propuesta</label>
                                                    <input value="" type="text" class="form-control" id="sub_titulo_1" name="sub_titulo_1" placeholder="">
                                                </div>
                                                <hr>
                                                <div class="form-group mt-1">
                                                    <label class="control-label">Contenido</label>
                                                    <textarea class="form-control" id="contenido" name="contenido" rows="8"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-12 mb-4">
                                            <div class="card h-100 p-1 shadow">
                                                <label class="control-label">Imagen</label></br>
                                                <input type="file" enctype="multipart/form-data" accept=".jpg,.png">
                                                        <!--<input type="file" class="form-control" id="imagen" name="imagen" placeholder="">-->
                                                <img class="img_mediumimg-fluid rounded-top mb-2" src="https://i.imgur.com/u4kt9Nb.jpeg">

                                                <a href="" class="button_editar text-center hero__cta agregador mb-2" id="">Subir Imagen<i class=""></i></a>

                                                <a href="" class="button_editar text-center hero__cta agregador" id="">Cargar Imagen<i class=""></i></a>
                                            </div>
                                        </div>
                                        @csrf
                                        <button class="button_editar mt-2 w-100" type="submit">Agregar</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
@endsection