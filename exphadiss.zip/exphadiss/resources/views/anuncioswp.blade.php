@extends('base')
@section('content')
                    <div class="card">
                        <form method="post">
                            <div class="card-body p-1">
                                <h4 class="text-inherit">Anuncios</h4>
                                @csrf
                                <button class="button_editar button-right" type="submit">Guardar</button>
                                <hr class="mt-2 mb-2">
                            <div class="container-fluid">
                                    <div class="row">
                                        <div class="col-lg-6 mb-4">
                                            <div class="card h-100 p-1 shadow">
                                                <div class="form-group">
                                                    <label class="control-label">Sub Titulo 1</label>
                                                    <input  @if($data && $data->sub_title) value="{{$data->sub_title}}" @endif type="text" class="form-control" id="sub_titulo_1" name="sub_titulo_1" placeholder="">
                                                </div>
                                                <hr>
                                                <div class="form-group mt-1">
                                                    <label class="control-label">Sub Titulo 2</label>
                                                    <input  @if($data && $data->sub_title_2) value="{{$data->sub_title_2}}" @endif type="text" class="form-control" id="sub_titulo_2" name="sub_titulo_2" placeholder="">
                                                </div>
                                                <hr>
                                                <div class="form-group mt-1">
                                                    <label class="control-label">Contenido</label>
                                                    <textarea class="form-control" id="contenido" name="contenido" rows="8">@if($data && $data->description){{$data->description}}@endif</textarea>
                                                </div>
                                                <hr>
                                                <div class="form-group mt-1">
                                                    <div class="content-buttons-general-text mb-1">
                                                        <h4 class="text-inherit">Boton</h4>
                                                        <div class="button-right-2">
                                                            <h4>Visible</h4>
                                                            <div class="switch">
                                                                <input type="checkbox" @if($data) @if($data->boton->visible) checked @endif @endif value="visi_anun" name="visi_anun" />
                                                                <div></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <input type="text" class="form-control" value="@if($data){{$data->boton->nombre}}@endif" id="name_boton_anun" name="name_boton_anun">
                                                    Link
                                                    <input type="text" class="form-control" value="@if($data){{$data->boton->link}}@endif" id="link_anun" name="link_anun">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 mb-4">
                                            <div class="card h-100 p-1 shadow">
                                                    <label class="control-label">Imagen</label></br>
                                                        <!--<input type="file" class="form-control" id="imagen" name="imagen" placeholder="">-->
                                                    <img data-name="imagenanuncios" class="bc-content-img2 cursor-pointer hero__cta img-fluid-2 rounded-top" name="imagenanuncios" src="@if($data){{$data->img_anuncios->img}}@endif">

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <input type="hidden" value="@if($data){{$data->img_anuncios->img}}@endif" class="form-control" id="imagenanuncios" name="imagenanuncios">
                        </form>
                    </div>
@endsection