@php
$time_banner = $time*1000;
@endphp

<!DOCTYPE html>
<html lang="es" class="js">
<head>
<meta charset="utf-8">

<meta name="viewport" content="width=device-width, initial-scale=1" />

<meta http-equiv="X-UA-Compatible" content="IE=edge" />

<title>Colegio Exphadis - José Gálvez</title>

<meta name="description" content="Institución Educativa Particular Colegio Exphadis, ubicada en Av. Mariam Quimper 897 - Altura del paradero 5 de la Av. Lima. - José Gálvez - Villa María del Triunfo. Lima, Perú. Educación con valores y tecnología para un Perú con futuro." />

<meta name="keywords" content="colegio exphadis,colegio exphadis jose galvez,colegio en jose galvez,colegio villa maria del triunfo,colegio en villa maria del triunfo,colegio en vmt,colegio vmt" />

<meta name="author" content="Colegio Exphadis - José Gálvez" />

<link rel="shortcut icon" type="image/ico" href="https://firebasestorage.googleapis.com/v0/b/exphadisprueba2022.appspot.com/o/292109841_401005132047260_5062265451483405999_n%20(2).ico?alt=media&token=16f7b3e2-7740-4653-a37e-56682811d75c" />

<link rel="canonical" href="https://colegioexphadis.com.pe/" />


<meta property="og:locale" content="es-ES" />

<meta property="og:title" content="Colegio Exphadis - José Gálvez" />

<meta property="og:description" content="Institución Educativa Particular Colegio Exphadis, ubicada en Av. Mariam Quimper 897 - Altura del paradero 5 de la Av. Lima. - José Gálvez - Villa María del Triunfo. Lima, Perú. Educación con valores y tecnología para un Perú con futuro." />

<meta property="og:url" content="https://colegioexphadis.com.pe/" />

<meta property="og:site_name" content="Colegio Exphadis - José Gálvez" />

<meta property="og:image" content="" />

<meta property="og:image:width" content="" />
<meta property="og:image:height" content="" />
<!-- Stylesheet================================================== -->
<link rel="stylesheet" type="text/css" href="/css/style-general.css" />
<link rel="stylesheet" type="text/css" href="/css/style.css" />
<link rel="shortcut icon" type="ico/icon" href="" />
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
<link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" />
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-63357240-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  console.log(<?php env('CODE_ANALITICS')?>);

  gtag('config', 'UA-63357240-1');
</script>
</head>
<body>
<!--PANTALLA DE CARGA-->
  <div class="preloader">
		<div class="loader-container">
				<img loading="lazy" src="https://firebasestorage.googleapis.com/v0/b/exphadisprueba2022.appspot.com/o/292109841_401005132047260_5062265451483405999_n.jpg?alt=media&token=17553484-3623-4a1f-9bee-6933b9851257" class="shadow">
    </div>
	</div>
<!--FIN DE PANTALLA DE CARGA-->


  <nav id="menu" class="navbar navbar-default navbar-fixed-top on">
    @if($admin->horario->visible)
      <div class="header_top_area">
        <div class="container">
          <div class="row">
            <div class="col-md-6 col-sm-6">
              <p class="text-center">@if($horarios){{$horarios->content_optional}} @endif</p>
            </div>
            <div class="col-md-6 col-sm-6 intranet">
              <a href="https://intranet.colegioexphadis.com.pe/"><i class="fa fa-user"></i> <p>Intranet</p></a>
            </div>
          </div>
        </div>
      </div>
    @endif
    @if($admin->menu->visible)
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"> <span class="sr-only"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
        <a href="/"><img loading="lazy" class="img-header-exphadis" src="@if($menu){{$menu->inicio->img}} @endif"></a></div>
      <div class="collapse navbar-collapse text-center" id="bs-example-navbar-collapse-1">
        <ul class="nav navbar-nav navbar-right">
          @foreach($menu as $link)
            @if($link->visible==true)
              <li><a href="{{$link->url}}" class="page-scroll active">{{$link->nombre}}</a></li>
            @endif
          @endforeach

        </ul>
      </div>
    </div>
    @endif
  </nav>
<!--<div class="space_nav"></div>-->
@if($admin->banner->visible)

  <div class="box-slider">


    <div class="swiper mySwiper background-white" style="--swiper-navigation-color: #fff; --swiper-pagination-color: #fff">
      <div class="swiper-wrapper">
      @foreach($banner as $key => $ban)
        <div class="swiper-slide swiper-lazy" loading="lazy" style="background-image:url('{{$ban->img}}');">
        </div>
      @endforeach
      </div>
      <!--<div class="swiper-pagination"></div>
      <div class="swiper-button-next"></div>
      <div class="swiper-button-prev"></div>-->
    </div>

  </div>
@endif

<!--Banner 1-->
@if($admin->nosotros->visible)
<section id="about-section">
  <div class="container">
    <div class="content-white-texto-exphadis">
    <div class="section-title">
      <h2 class="fw-8 text-center">@if($nosotros){{$nosotros->title_seccion}} @endif</h2>
      <hr>
    </div>
    <div class="row flex-center padding_content_nosotros">
      <div class="col-lg-6 col-md-5 order-md-1" style="position:relative;">
        <img loading="lazy" class="shadow img-responsive" style="" src="@if($nosotros){{$nosotros->content_optional}} @endif" alt="Nosotros Exphadis" />
      </div>
      <div class="col-md-6 col-lg-6">
        <h3 class="fw-bold color-text-exphadis text-align-left">@if($nosotros){{$nosotros->sub_title}} @endif<br><h2 class="text-align-left"><span class="fw-bold">@if($nosotros){{$nosotros->sub_title_2}} @endif</span></h2></h3>
        <p class="mt-3 mb-3">@if($nosotros){{$nosotros->description}} @endif</p>
      </div>
    </div>
    </div>
  </div>
</section>
@endif
@if($admin->pilares->visible)
<section class="pb-6 banner1">
  <div class="container">
    <div class="section-title">
      <h3 class="text-center"><strong class="color-text-exphadis fw-8">@if($title){{$title}} @endif</strong><br>@if($subtitle){{$subtitle}} @endif</h3>
      <hr>
    </div>
    <div class="wrapper-pilar">
      <div class="line"></div>

      @foreach($pilar as $key => $pilar)
      @if($key!='pilar')
      @if($pilar->visible)
      <div class="pilar {{$pilar->clase}}">
        <div class="container-cubo">
          <div class="cubo">
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <img loading="lazy" src="{{$pilar->img}}">
          </div>
        </div>
        <span class="dot"></span>
        <h3>{{$pilar->titulo}}</h3>
        <p>{{$pilar->descripcion}}</p>
      </div>
      @endif
      @endif
      @endforeach
    </div>
  </div>
  <!-- end of .container-->
</section>
@endif
@if($admin->propuesta->visible)
<div id="services-section"></div>
<!--============PROPUESTAS============-->
<!-- About Section -->
<div class="padding-content-min">
<div class="bg"></div>
<div class="bg bg2"></div>
<div class="bg bg3"></div>
  <div class="container">
    <div class="section-title">
      <h2 class="fw-8 color-white text-center">{{$propuesta->propuesta->titulo}}</h2>
      <hr class="background-white">
    </div>
    <div class="container-fluid-2">
      <div class="row-2">
        @foreach($propuesta as $key => $prop)
        @if($key!='propuesta')
        @if($prop->visible)
        <div class="rs_order_2 rs_order_3 p-1"><!--rs_order_1 rs_order_4-->
          <div class="card2 h-100 p-1 shadow_2">
            <div class="card-body2">
              <img loading="lazy" src="{{$prop->img}}" class="img-responsive-2 rounded-top" alt="colegioexphadis">
              <div class="text-propuesta">
                <h4 class="fw-8">{{$prop->titulo}}</h4>
                <p class="responsive-text-p fw-bold">{{$prop->descripcion}}</p>
              </div>
            </div>

          </div>
        </div>
        @endif
        @endif
        @endforeach
      </div>
    </div>
  </div>
</div>
@endif
@if($admin->galeria->visible)
<div id="works-section">
    <div class="section-title">
      <h2 class="fw-8 titles-exphadis text-center">@if($titulo){{$titulo}} @endif</h2>
      <hr>
      <div class="clearfix"></div>
    </div>
    <section style="
    width: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;">
        <ul>
            <li class="list active" data-filter="all">Todos</li>
            @foreach($galeria as $gal)
            @if($gal->visible)
            <li class="list" data-filter=".{{str_replace(' ','-',$gal->titulo)}}">{{$gal->titulo}}</li>
            @endif
            @endforeach
        </ul>
        <div class="product">
            @foreach($galeria as $gal)
            @if($gal->visible)
            @foreach($gal->imgs as $img)
            <div class="itemBox bg2" data-item=".{{str_replace(' ','-',$gal->titulo)}}">
              <a class="bg2">
                <img loading="lazy" class="bg2" src="{{$img}}" alt="" />
              </a>
            </div>
            @endforeach
            @endif
            @endforeach

        </div>
    </section>
</div>
@endif
<!--<section class="modal ">
  <div class="modal__container">
      <img src="" class="modal__img">
      <i class="modal__close fa fa-window-close"></i>
      <a class="btn btn-default" href="https://www.facebook.com/exphadis/photos/?ref=page_internal">Ver mas fotos</a>
  </div>
</section>-->
@if($admin->anuncios->visible)
<section class="pb-6 background-white-2">
  <div class="banner-efect">
    <div class="banner-efect-2">
  <div class="container">
      <div class="row flex-center padding-content">

        <div class="col-md-6 col-lg-6" style="margin-bottom: 2rem;">
          <h3 class="fw-bold color-text-exphadis text-align-left text-white">@if($anuncioswp_subtitle){{$anuncioswp_subtitle}} @endif<br><h2 class="text-align-left text-white"><span class="fw-bold">@if($anuncioswp_subtitle_2){{$anuncioswp_subtitle_2}} @endif</span></h2></h3>
          <p class="mt-3 mb-3 text-white fw-bold">@if($anuncioswp_cont){{$anuncioswp_cont}} @endif</p>
          @if($anuncios_options->boton->visible)
          <a class="btn-portafolio-2" href="@if($anuncios_options){{$anuncios_options->boton->link}} @endif">@if($anuncios_options){{$anuncios_options->boton->nombre}} @endif</a>
          @endif
        </div>
        <div class="col-lg-6 col-md-5 order-md-1" style="position:relative;">
          <img loading="lazy" class="shadow img-responsive" src="@if($anuncios_options){{$anuncios_options->img_anuncios->img}} @endif" alt="@if($anuncioswp_cont){{$anuncioswp_cont}} @endif" />
        </div>

      </div>
    </div>
  </div>
  <!-- end of .container-->
</section>
@endif
<!--================Contact Section================ -->
<div class="w-100 p-0 text-center background-white">
@if($admin->googlemaps->visible)
<iframe loading="lazy" src="@if($googlemaps){{$googlemaps->content_optional}} @endif" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
@endif
<!-- Footer Start -->
@if($admin->contacto->visible)
<footer>
  <div id="contact-section">
    <div class="row-footer">

      <div class="col-footer">
        <h3>Niveles:<div class="underline"><span></span></div></h3>
        @if($contacto)
        @if($key!='contacto')
        <p>{{$contacto->niveles->nivel1}}</p>
        <p>{{$contacto->niveles->nivel2}}</p>
        <p>{{$contacto->niveles->nivel3}}</p>
        @endif
        @endif
      </div>
      <div class="col-footer">
        <h3>Visítanos:<div class="underline"><span></span></div></h3>
        @if($contacto)
        @if($key!='contacto')
        <p><i class="fas fa-map-marker-alt"></i>{{$contacto->visitanos->ubicacion}}</p>
        @endif
        @endif

      </div>
      <div class="col-footer">
        <h3>Telefónica:<div class="underline"><span></span></div></h3>
        @if($contacto)
        @if($key!='contacto')
        <p><i class="fas fa-phone-alt"></i>{{$contacto->telefonica->num1}}</p>
        <p><i class="fas fa-phone-alt"></i>{{$contacto->telefonica->num2}}</p>
        @endif
        @endif


      </div>

    </div>
  </div>
</footer>
@endif
</div>
<!-- Footer End -->
<!--================CONVERSEMOS===============-->
@if(count($redes)>0)
<div id="social-icons">
  <div class="text-right">
      <ul class="social-icons">
          <div class="social-btn-container">


            @foreach($redes as $red)
            @if($red->bool)
            <span class="{{$red->clase}}">
                <a href="{{$red->link_redes}}" class="{{$red->clase1}}">
                  <i class="{{$red->clase2}}"></i>
                </a>
            </span>
            @endif
            @endforeach

          </div>
      </ul>
  </div>
</div>
@endif

<div id="footer">
  <div class="container">
    <p class="text-center">Copyright &copy; Diseñado por colegioexphadis.pe<a href="" rel="nofollow"></a></p>
  </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script>
  const preloader = document.querySelector(".preloader");

  window.addEventListener("load", () =>{
    preloader.style.display= "none";
  })
</script>
<script type="text/javascript" src="js/jquery.isotope.js"></script>
<script type="text/javascript" src="js/main.js"></script>
<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
<script>
var swiper = new Swiper(".mySwiper", {
        /*spaceBetween: 30,*/
        centeredSlides: true,
        autoplay: {
          delay: <?= $time_banner?>,
          disableOnInteraction: false,
        },
        pagination: {
          el: ".swiper-pagination",
          clickable: true,
        },
        navigation: {
          nextEl: ".swiper-button-next",
          prevEl: ".swiper-button-prev",
        },
      });
</script>
<script>
let list = document.querySelectorAll('.list');
let itemBox = document.querySelectorAll('.itemBox');

for(let i = 0; i<list.length; i++){
    list[i].addEventListener('click', function(){
        for(let j = 0; j<list.length; j++){
            list[j].classList.remove('active');
        }
        this.classList.add('active');

        let dataFilter = this.getAttribute('data-filter');

        for(let k = 0; k<itemBox.length; k++){
            itemBox[k].classList.remove('active');
            itemBox[k].classList.add('hide');

        if(itemBox[k].getAttribute('data-item') == dataFilter || dataFilter == "all"){
            itemBox[k].classList.remove('hide');
            itemBox[k].classList.add('active');
        }
    }
    })
}
</script>
</body>
</html>
