@extends('base')
@section('content')
                    <div class="card">
                        <form method="post">
                            <div class="card-body p-1">
                                <h4 for="menu" class="text-inherit">Horario Web Principal</h4>
                                @csrf
                                <button class="button_editar button-right" type="submit">Guardar</button>
                                <hr class="mt-2 mb-2">
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="col-lg-6 col-12 mb-4">
                                            <div class="card h-100 p-1 shadow">
                                                <h4 class="text-inherit">Horario</h4>
                                                <input value="{{$data->content_optional}}" required type="text" class="form-control" id="" name="titulo">
                                            </div>
                                        </div>
                                        <!--<div class="col-xxl-3 col-xl-4 col-lg-6 col-12 mb-4">
                                            <div class="card h-100 p-1 shadow">
                                                <label class="control-label">Intranet</label>
                                                <div class="boton">
                                                    <h4>Visible</h4>
                                                    <div class="switch">
                                                        <input type="checkbox" />
                                                        <div></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>-->

                                    </div>
                                </div>   
                            </div>
                        </form>
                    </div>
@endsection