@extends('base')
@section('content')
<form method="post">
                    <div class="card container-fluid">
                        <div class="card-body p-1">
                            <h4 for="menu" class="text-inherit">Formulario</h4>
                                     @csrf
                                    <button class="button_editar button-right" type="submit">Guardar</button>
                            <hr class="mt-2 mb-2">
                                <div class="container-fluid">
                                    <div class="row">
                                    
                                        <div class="col-lg-6 mb-4">
                                            <div class="card h-100 p-2 shadow">
                                                <h4 class="text-inherit">Titulo</h4>
                                                <hr>
                                                <input type="text" @if($data && $data->title_seccion) value="{{$data->title_seccion}}" @endif name="tituloform" class="form-control">
                                                <hr>
                                                <h4 class="text-inherit">Sub Titulo</h4>
                                                <input type="text" @if($data && $data->sub_title) value="{{$data->sub_title}}" @endif name="sub_tituloform" class="form-control">
                                                <hr>
                                            </div>
                                        </div>


                                        <div class="col-lg-6 mb-4">
                                            <div class="card h-100 p-2 shadow">
                                            <h4 class="text-inherit">Correo Colegio Exphadis</h4>
                                            <hr>
                                            <input type="text" @if($data && $data->content_optional) value="{{$data->content_optional}}" @endif name="correo" class="form-control">
                                            <hr>
                                            </div>
                                        </div>
                                        
                                    </div>
                                </div>
                            
                        </div>
                    </div>
</form>
@endsection