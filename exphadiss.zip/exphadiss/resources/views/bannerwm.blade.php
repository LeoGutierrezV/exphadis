@extends('base')
@section('content')
<div class="card">
                        <form method="post">
                            <div class="card-body p-1">
                                <div class="container-fluid">
                                <h4 for="menu" class="text-inherit">Banner Matricula</h4>
                                @csrf
                                <button class="button_editar button-right" type="submit">Guardar</button>
                                <hr class="mt-2 mb-2">
                                    <div class="row">
                                        <div class="col-lg-6 mb-4">
                                            <div class="card h-100 p-1 shadow">
                                                <div class="form-group">
                                                    <h4 class="text-inherit">Titulo</h4>
                                                    <input type="text" @if($data && $data->title_seccion) value="{{$data->title_seccion}}" @endif class="form-control" name="titulo_banner_wm" >
                                                </div>
                                                <hr class="mb-1">
                                                <div class="form-group">
                                                    <h4 class="text-inherit">Sub Titulo</h4>
                                                    <input type="text" @if($data && $data->sub_title) value="{{$data->sub_title}}" @endif class="form-control" name="subtitulo_banner_wm">
                                                </div>
                                                <hr>
                                                <div class="form-group mt-1">
                                                    
                                                    <div class="content-buttons-general-text mb-1">
                                                        <h4 class="text-inherit">Contenido</h4>
                                                    </div>
                                                    <textarea class="form-control" id="contenido_wm_banner" name="contenido_wm_banner" rows="8">@if($data && $data->description){{$data->description}}@endif</textarea>
                                                    
                                                </div>
                                                <hr>
                                                <div class="form-group mt-1">
                                                    <div class="content-buttons-general-text mb-1">
                                                        <h4 class="text-inherit">Boton</h4>
                                                            <div class="button-right-2">
                                                                <h4>Visible</h4>
                                                                <div class="switch">
                                                                    <input type="checkbox" @if($data) @if($data->boton->visible) checked @endif @endif value="bannercheck1" name="bannercheck1" />
                                                                    <div></div>
                                                                </div>
                                                            </div>
                                                    </div>
                                                    <input type="text" value="@if($data){{$data->boton->nombre}}@endif" class="form-control" name="text_btn1_banner">
                                                    Link
                                                    <input type="text" value="@if($data){{$data->boton->link}}@endif" class="form-control" name="link_btn1_banner">
                                                </div>
                                                <hr>
                                            </div>
                                        </div> 
                                        <div class="col-lg-6 mb-4">
                                            <div class="card h-100 p-1 shadow">
                                                    <h4 class="text-inherit">Imagen</h4></br>
                                                        <!--<input type="file" class="form-control" id="imagen" name="imagen" placeholder="">-->
                                                    <img data-name="banner_imagen_wm" class="hero__cta bc-content-img2 cursor-pointer img-fluid" name="banner_imagen_wm" src="@if($data){{$data->img_bannerwm->img}}@endif">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <input type="hidden" value="@if($data){{$data->img_bannerwm->img}}@endif" class="form-control" id="banner_imagen_wm" name="banner_imagen_wm">
                        </form>
                    </div>
@endsection