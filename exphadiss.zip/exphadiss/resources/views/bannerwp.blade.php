@extends('base')
@section('content')
<form method="post">
                    <div class="card">
                      <div class="card-body p-1">
                        <h4 for="menu" class="text-inherit">Banner Web Principal</h4>
                        @csrf
                        <button class="button_editar shadow mb-2 button_guardaddor" style="display: block;position:absolute;right: 6.9rem;top: 1rem;" id="">Guardar<i class=""></i></button>
                        <button class="button_editar button-right shadow agregador" type="submit">Agregar</button>
                        
                        <div class="dropdown">
                          <button class="dropbtn"><i class="bx bx-cog"></i></button>
                          <ul class="dropdown-content">
                            <li>
                              <h3 class="text-inherit">Velocidad:</h3>
                              <input type="number" type="text" value="@if($time_banners){{$time_banners}}@endif" class="form-control" id="time_banners" name="time_banners">
                            </li>
                          </ul>
                        </div>
                        <hr class="mt-2 mb-2">
                        <div class="container-fluid">
                          <style>
                            .dropbtn {
                              background-color: #04AA6D;
                              color: white;
                              padding: 5px 7px 5px 7px;
                              font-size: 16px;
                              border: none;
                              border-radius: 10px;
                            }
                            .dropdown {
                              display: block;position:absolute;right: 12rem;top: 1rem;
                            }
                            .dropdown-content {
                              display: none;
                              position: absolute;
                              background-color: #f1f1f1;
                              min-width: 25vh;
                              right:0.2rem;
                              box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                              z-index: 1;
                              list-style: none;
                              
                            }
                            .dropdown-content li{
                              text-decoration:none;
                              font-size: 10px;
                              padding: 2px 7px 2px 7px;
                            }
                            .dropdown-content li h3{
                              margin-top: 8px;
                            }
                            .dropdown-content li input{
                              height: 25px !important;
                            }
                            .dropdown:hover .dropdown-content {display: block;}

                            .dropdown:hover .dropbtn {background-color: #3e8e41;}
                          </style>
                        
                          <div class="row contenedorfachero">
                            
                            <!--aca se carga todo-->

                          </div>
                        </div>
                      </div>
                          
                    </div>
                    
                      @csrf
                      <input id="formvalue" type="hidden" name="dataenv" value="{{$banners}}">
                    </form>

<data-lynn style="display:none;">{{$banners}}</data-lynn>
<script>
  let js=null;
  let ids = [];
  let input = document.querySelector('#formvalue');
  let form = document.querySelector('form');
  let guardar = document.querySelector('.button_guardaddor');
  let agregador = document.querySelector('.agregador');
  
  agregador.addEventListener('click',(e)=>{
    e.preventDefault();
    if(e.isTrusted){
      let dataLynn = document.querySelector('data-lynn');
      js = JSON.parse(dataLynn.innerHTML);
      js.push({img:"nullasd"});

      input.value = JSON.stringify(js);
      document.querySelector('data-lynn').innerHTML = JSON.stringify(js);
      parser();
    }
  })


  guardar.addEventListener('click',()=>{
    refresh();
    // parser();
    form.submit();
  });

  // Object.values(document.querySelectorAll('.subir')).map(el=>{
  // })



  function parser(){
    let dataLynn = document.querySelector('data-lynn');
    js = JSON.parse(dataLynn.innerHTML);
    ids = [];
    document.querySelector('.contenedorfachero').innerHTML = '';
    js.map((el,index)=>{
      document.querySelector('.contenedorfachero').innerHTML += `
      <div class="col-xl-4 col-lg-6 mb-4">
                              <div class="card h-100 p-1 shadow">
                              <div class="cursor-pointer" >
                                <img data-name="banner${index}" data-banner="true" src="${el.img}" class="banner${index} bc-img cursor-pointer hero__cta img-fluid-2 rounded-top">
                              </div>
                              <input type="hidden" value="${el.img}" id="banner${index}"/>
                                <div class="card-body">
                                  <div class="container">
                                    <div class="row">
                                        <div class="col-md-12 mb-2"><!--col-xxl-3 col-xl-4 col-lg-6-->
                                          <button data-index="${index}" class="trash-estilos w-100 v"><i class="fa-solid fa-trash"></i></button>
                                        </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
      `;
      ids.push('banner'+index);
    })

    ids.map(el=>{
      document.querySelector('#'+el).addEventListener('change',()=>{
        refresh();
      });
    });

    trash();
    input.value = JSON.stringify(js);
  }

  function refresh(){
    js = [];
    ids.map(el=>{
      js.push({img:document.querySelector('.'+el).src});
    });
    document.querySelector('data-lynn').innerHTML = JSON.stringify(js);
    input.value = JSON.stringify(js);
    parser();
    
  }

  function trash(){
    Object.values(document.querySelectorAll('.trash-estilos')).map(el=>{
      el.addEventListener('click',(e)=>{
        let semi = [];
        
        js.map((ell,index)=>{
          if(parseInt( el.dataset.index)!=index){
            semi.push(ell);
          }
        })

        js = semi;
        console.log(js)
        document.querySelector('data-lynn').innerHTML = JSON.stringify(js);
        input.value = JSON.stringify(js);


        el.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.remove()
        parser();
      });
    })
  }


  parser();
</script>
@endsection