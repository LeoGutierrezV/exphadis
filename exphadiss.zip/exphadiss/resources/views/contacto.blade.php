@extends('base')
@section('content')
<form method="post">
                    <div class="card container-fluid">
                        <div class="card-body p-1">
                            <h4 for="menu" class="control-label">Contacto</h4>
                                     @csrf
                                    <button class="button_editar button-right" type="submit">Guardar</button>
                            <hr class="mt-2 mb-2">
                                <div class="container-fluid">
                                    <div class="row">
                                    
                                        <div class="col-xl-4 col-lg-6 mb-4">
                                            <div class="card h-100 p-2 shadow">
                                            <h4 class="text-inherit">Niveles</h4>
                                            <hr>
                                            <input type="text" value="@if($data){{$data->niveles->nivel1}}@endif" name="nivel1" class="form-control">
                                            <hr>
                                            <input type="text" value="@if($data){{$data->niveles->nivel2}}@endif" name="nivel2" class="form-control">
                                            <hr>
                                            <input type="text" value="@if($data){{$data->niveles->nivel3}}@endif" name="nivel3" class="form-control">
                                            <hr>
                                            </div>
                                        </div>
                                        <div class="col-xl-4 col-lg-6 mb-4">
                                            <div class="card h-100 p-2 shadow">
                                            <h4 class="text-inherit">Visitanos</h4>
                                            <hr>
                                            <textarea class="form-control mt-1 mb-1" id="ubicacion" name="ubicacion" rows="5">@if($data){{$data->visitanos->ubicacion}}@endif</textarea>
                                            <hr>
                                            </div>
                                        </div>
                                        
                                        <div class="col-xl-4 col-lg-6 mb-4">
                                            <div class="card h-100 p-2 shadow">
                                            <h4 class="text-inherit">Telefonica</h4>
                                            <hr>
                                            <input type="text" value="@if($data){{$data->telefonica->num1}}@endif" name="num1" class="form-control">
                                            <hr>
                                            <input type="text" value="@if($data){{$data->telefonica->num2}}@endif" name="num2" class="form-control">
                                            <hr>
                                            </div>
                                        </div>

                                        <div class="col-lg-6 mb-4">
                                            <div class="card h-100 p-2 shadow">
                                            <h4 class="text-inherit">Copyright</h4>
                                            <hr>
                                            <input type="text" value="" name="" class="form-control">
                                            <hr>
                                            </div>
                                        </div>
                                        
                                    </div>
                                </div>
                            
                        </div>
                    </div>
</form>
@endsection