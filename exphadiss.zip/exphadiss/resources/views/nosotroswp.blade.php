@extends('base')
@section('content')
                    <div class="card">
                        <form method="post">
                            <div class="card-body p-1">
                                <h4 class="text-inherit">Nosotros Web Principal</h4>
                                @csrf
                                <button class="button_editar button-right" type="submit">Guardar</button>
                                <hr class="mt-2 mb-2">
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="col-lg-6 mb-4">
                                            <div class="card h-100 p-1 shadow">
                                                <div class="form-group">
                                                    <h4 class="text-inherit">Titulo</h4>
                                                    <input type="text" @if($data && $data->title_seccion) value="{{$data->title_seccion}}" @endif  class="form-control" id="titulo" name="titulo" placeholder="">
                                                </div>
                                                <hr>
                                                <div class="form-group mt-1">
                                                    <h4 class="text-inherit">Sub Titulo 1</h4>
                                                    <input  @if($data && $data->sub_title) value="{{$data->sub_title}}" @endif type="text" class="form-control" id="sub_titulo_1" name="sub_titulo_1" placeholder="">
                                                </div>
                                                <hr>
                                                <div class="form-group mt-1">
                                                    <h4 class="text-inherit">Sub Titulo 2</h4>
                                                    <input  @if($data && $data->sub_title_2) value="{{$data->sub_title_2}}" @endif type="text" class="form-control" id="sub_titulo_2" name="sub_titulo_2" placeholder="">
                                                    <br>
                                                </div>
                                                <hr>
                                                <div class="form-group mt-1">
                                                    <h4 class="text-inherit">Contenido</h4>
                                                    <textarea class="form-control" id="contenido" name="contenido" rows="8">@if($data && $data->description){{$data->description}}@endif</textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 mb-4">
                                            <div class="card h-100 p-1 shadow">
                                                    <h4 class="text-inherit">Imagen</h4></br>
                                                    <img data-name="imagennosotros" src="@if($data){{$data->content_optional}}@endif" class="bc-content-img2 cursor-pointer hero__cta img-fluid-2 rounded-top" name="imagennosotros">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <input type="hidden" id="imagennosotros" value="@if($data){{$data->content_optional}}@endif" name="imagennosotros">
                        </form>
                    </div>
                    
@endsection