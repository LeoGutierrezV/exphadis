@extends('base')
@section('content')
<form action="" class="formmmmasdas" method="post">
<div class=""><!--card-->
    
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 mb-4">
                <div class="p-1 shadow"><!--card-->
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card p-1 shadow">
                                <div class="mb-1">
                                <h4 class="text-inherit">Matricula</h4>
                                @csrf
                                <button class="button_editar button-right agregarcard_matricula" type="button">Guardar</button>
                                <hr class="mt-2 mb-2">
                                </div>
                            </div>
                            
                        </div>
                        <div class="col-lg-6">
                            <div class="card p-1 shadow">
                                <div class="mb-1">
                                    <h4 class="text-inherit">Titulo</h4>
                                    <input type="text" value="@if($titulo){{$titulo}}@endif" class="form-control" name="titulo_matricula_cont" >
                                </div>
                            </div>
                            
                        </div>
                        <div class="col-lg-6">
                            <div class="card p-1 shadow">
                                <div class="mb-1">
                                    <h4 class="text-inherit">Sub Titulo</h4>
                                    <input type="text" value="@if($subtitu){{$subtitu}}@endif" class="form-control" name="sub_titulo_matricula_cont">
                                </div>
                            </div>
                        </div>
                        
                            <style>


                            </style>
                                <div class="popup-box">
                                    <div class="popup">
                                        <div class=" container content_emergent">
                                        <header>
                                            <p></p>
                                            <i class="btn_close_matri bx bx-window-close"></i>
                                        </header>
                                        <div class="form_emergent">
                                            <div class="row-2_emergente">
                                                    <div class="col-lg-6 p-1">
                                                        <div class="row_emergent title">
                                                        <h4 class="text-inherit">Titulo</h4>
                                                        <input class="title_matri form-control" type="text" spellcheck="false">
                                                        </div>
                                                        <div class="row_emergent description">
                                                        <h4 class="text-inherit">Contenido</h4>
                                                        <textarea class="content_matri form-control" rows="4" spellcheck="false"></textarea>
                                                        </div>
                                                        <button class="add_matri"></button>
                                                    </div>
                                                    <div class="col-lg-6 p-1 mt-1">
                                                        <img src="https://firebasestorage.googleapis.com/v0/b/exphadisprueba2022.appspot.com/o/292109841_401005132047260_5062265451483405999_n.jpg?alt=media&token=17553484-3623-4a1f-9bee-6933b9851257" class="shadow img_cards_matri cursor-pointer bc-img hero__cta img-fluid rounded-top">
                                                    </div>
                                                    <div class="wrapper container mb-1">
                                                        <div class="child-tab">
                                                            <input type="checkbox" style="display: none;" name="sub-tab" id="tab-4">
                                                            <label for="tab-4">
                                                                <span><h4 class="text-inherit">Ventanas Emergentes</h4></span>
                                                                <div class="icon"><i class="fas fa-plus"></i></div>
                                                            </label>
                                                            <div class="sub-content container mt-1">
                                                                <div class="row">
                                                                    <div class="col-lg-6">
                                                                        <div class="row_emergent">
                                                                            <h4 class="text-inherit text-col1">Requisitos:</h4>
                                                                            <input class="form-control titulo cont1_title_matri" type="text" spellcheck="false">
                                                                        </div>
                                                                        <div class="row_emergent">
                                                                            <div class="content-buttons-general-text mb-1">
                                                                                <h4 class="text-inherit ">Contenido</h4>
                                                                            </div>
                                                                            <div class=""></div>
                                                                            <textarea class="form-control contenido cont1_desc_matri" rows="4" spellcheck="false"></textarea>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-lg-6">
                                                                        <div class="row_emergent">
                                                                        <h4 class="text-inherit">Matricula:</h4>
                                                                        <input class="form-control titulo cont2_title_matri" type="text" spellcheck="false">
                                                                        </div>
                                                                        <div class="row_emergent">
                                                                            <div class="content-buttons-general-text mb-1">
                                                                                <h4 class="text-inherit">Contenido</h4>
                                                                            </div>
                                                                            <textarea class="form-control contenido cont2_desc_matri" rows="4" spellcheck="false"></textarea>
                                                                        </div>
                                                                    </div>

                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                            </div>
                                        </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="container">
                                    <div class="row">
                                    
                                            <li class="add-box w-100">
                                                <div class="card p-1 h-100 shadow">
                                                        <div class="icon"><i class="uil bx bx-plus"></i></div>
                                                        <p>Agregar Card</p>
                                                    </div>
                                                </div>
                                            </li>
                                    </div>
                                </div>

                    </div>
                </div>
            </div>
        </div>
    </div>              
</div>
@csrf
    <input type="hidden" id="asda"name="datitos"value="">
</form>
<script>
const addBox = document.querySelector(".add-box"),
btn_guardar = document.querySelector(".agregarcard_matricula"),
popupBox = document.querySelector(".popup-box"),
popupTitle = popupBox.querySelector("header p"),
closeIcon = popupBox.querySelector("header i"),
titleTag = popupBox.querySelector(".title_matri"),
descTag = popupBox.querySelector(".content_matri"),
cont1_title = popupBox.querySelector(".cont1_title_matri"),
cont1_desc = popupBox.querySelector(".cont1_desc_matri"),
cont2_title = popupBox.querySelector(".cont2_title_matri"),
cont2_desc = popupBox.querySelector(".cont2_desc_matri"),
img_cards = popupBox.querySelector(".img_cards_matri"),
addBtn = popupBox.querySelector(".add_matri");


const months = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio",
              "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];
const notes = JSON.parse('{!!$data!!}');

let isUpdate = false, updateId;

addBox.addEventListener("click", () => {

    popupTitle.innerText = "Agrega una card";
    addBtn.innerText = "Agregar Card";
    popupBox.classList.add("show");
    document.querySelector("body").style.overflow = "hidden";
    if(window.innerWidth > 660) titleTag.focus();
});

closeIcon.addEventListener("click", () => {
    isUpdate = false;
    titleTag.value = descTag.value = "";
    popupBox.classList.remove("show");
    document.querySelector("body").style.overflow = "auto";
});

function showNotes() {
    if(!notes) return;
    document.querySelectorAll(".note").forEach(li => li.remove());
    notes.map((note, ind) => {
        let filterDesc = note.contenido.replaceAll("\n", '<br/>');
        let liTag = `
                <div class="col-xl-4 col-lg-6 mb-4">
                    <div class="note">
                        <div class="container">
                            <div class="row-2_emergente mb-1">
                                <div class="col-md-6 col-lg-6">
                                    <input disabled class="form-control" value="${note.titulo}"/>
                                    <textarea class="form-control" disabled rows="4">${filterDesc}</textarea>
                                </div>
                                <div class="col-md-6 col-lg-6 mt-1">
                                    <img src="${note.img}" class="img-fluid">
                                </div>
                            </div>
                        </div>
                            
                        <div class="bottom-content">
                            <span>${note.date}</span>
                            <div class="settings">
                                <i onclick="showMenu(this)" class="uil bx bx-menu-alt-right"></i>
                                <ul class="menu">
                                    <li onclick="updateNote(${ind})"><i class="uil bx bx-edit"></i>Editar</li>
                                    <li onclick="deleteNote(${ind})"><i class="uil bx bx-trash"></i>Eliminar</li>
                                </ul>
                            </div>
                        </div>
                    </div>
            </div>`;
        addBox.insertAdjacentHTML("afterend", liTag);
    });
}
showNotes();


function showMenu(elem) {
    elem.parentElement.classList.add("show");
    document.addEventListener("click", e => {
        if(e.target.tagName != "I" || e.target != elem) {
            elem.parentElement.classList.remove("show");
        }
    });
}
btn_guardar.addEventListener('click',()=>{
    
    document.getElementById('asda').value = JSON.stringify(notes);
    document.querySelector('.formmmmasdas').submit();
});

async function deleteNote(noteId) {
    let  confirmDel  = await swal("¿Esta seguro de eliminar esta card?", {
        icon: "warning" ,
        dangerMode: true,
        buttons: true,
        });
    if(!confirmDel) return;
    notes.splice(noteId, 1);
    localStorage.setItem("notes", JSON.stringify(notes));
    showNotes();
}

function updateNote(noteId) {
    let note = notes[noteId];
    let description = note.contenido;
    let textt = '';
    let textt2 = '';
    updateId = noteId;
    isUpdate = true;
    addBox.click();
    titleTag.value = note.titulo;
    cont1_title.value = note.col1.titulo;
    note.col1.contenido.map(res=>textt+=res+'\n');

    cont2_title.value = note.col2.titulo;
    note.col2.contenido.map(res=>textt2+=res+'\n');

    cont1_desc.value = textt;
    cont2_desc.value = textt2;

    descTag.value = note.contenido;
    popupTitle.innerText = "Actualizar Cards";
    addBtn.innerText = "Actualizar Card";
}

addBtn.addEventListener("click", e => {
    e.preventDefault();
    let title = titleTag.value.trim(),
    description = descTag.value.trim(),
    cont1_t = cont1_title.value.trim(),
    cont1 = cont1_desc.value.trim(),
    cont2_t = cont2_title.value.trim();
    cont2 = cont2_desc.value.trim();

    if(title || description) {
        let currentDate = new Date(),
        month = months[currentDate.getMonth()],
        day = currentDate.getDate(),
        year = currentDate.getFullYear();

        let noteInfo = {
            titulo: title,
            contenido: description,
            img: img_cards.src,
            date: `${month} ${day}, ${year}`,
            col1: {titulo: cont1_t,contenido: cont1.split("\n")},
            col2: {titulo: cont2_t,contenido: cont2.split("\n")}
        }

        if(!isUpdate) {
            notes.push(noteInfo);
        } else {
            isUpdate = false;
            notes[updateId] = noteInfo;
            //notes[updateId].img = img_cards_cont.src;
        }
        //localStorage.setItem("notes", JSON.stringify(notes));
        //document.querySelector('notes').innerHTML = JSON.stringify(notes);


        showNotes();
        closeIcon.click();
    }

});

</script>


@endsection