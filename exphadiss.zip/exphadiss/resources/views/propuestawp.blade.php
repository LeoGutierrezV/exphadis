@extends('base')
@section('content')
<form method="post">
    @csrf       <div class="card">
                        <div class="card-body p-1">
                            <h4 class="text-inherit">Servicios Web Principal</h4>
                            @csrf
                            <button class="button_editar agregador button-right" id="">Guardar<i class=""></i></button>
                            <hr class="mt-2">
                            <div class="container-fluid">
                            <div class="row">
                                        <div class="col-md-12 mb-4">
                                            <div class="card h-100 p-1 shadow">
                                                <div class="card-body">
                                                    <h4 class="text-inherit">Titulo</h4>
                                                    <input type="text" value="@if($data){{$data->propuesta->titulo}}@endif" name="title" class="form-control" >
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-4 col-lg-6 mb-4">
                                            <div class="card h-100 p-1 shadow">
                                                <div class="card-body">
                                                    <div class="form-group">
                                                        <div class="mb-1">
                                                            <h4 class="text-inherit">Propuesta 1</h4>
                                                        </div>
                                                        <div class="button-right">
                                                            <h4>Visible </h4>
                                                            <div class="switch">
                                                                <input type="checkbox" value="visible1" @if($data) @if($data->propuesta1->visible) checked @endif @endif name="visible1" />
                                                                <div></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                        <div class="hero__cta bc-img cursor-pointer" data-name="img1">
                                                            <img data-name="img1" src="@if($data){{$data->propuesta1->img}}@endif" class="cursor-pointer img-fluid-2">
                                                        </div>
                                                        <div class="card-body">
                                                            <div class="mb-4 container">
                                                                <h4 class="mb-0 text-inherit">Titulo</h4>
                                                                <input type="text" value="@if($data){{$data->propuesta1->titulo}}@endif" name="title1" class="form-control">
                                                            </div>
                                                            <hr class="mb-1">
                                                            <div class="mb-4 container">
                                                              <h4 class="mt-1 mb-0 text-inherit">Contenido</h4>
                                                            <textarea class="form-control" id="contenido" name="desc1" rows="8">@if($data){{$data->propuesta1->descripcion}}@endif</textarea>
                                                            </div>
                                                        </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-4 col-lg-6 mb-4">
                                            <div class="card h-100 p-1 shadow">
                                                <div class="card-body">
                                                    <div class="form-group">
                                                        <div class="mb-1">
                                                            <h4 class="text-inherit">Propuesta 2</h4>
                                                        </div>
                                                        <div class="button-right">
                                                            <h4>Visible </h4>
                                                            <div class="switch">
                                                                <input type="checkbox" @if($data) @if($data->propuesta2->visible) checked @endif @endif value="visible2" name="visible2" />
                                                                <div></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                        <div class="hero__cta bc-img cursor-pointer" data-name="img2">
                                                            <img data-name="img2" src="@if($data){{$data->propuesta2->img}}@endif" class="cursor-pointer hero__cta img-fluid-2 rounded-top">
                                                        </div>
                                                        <div class="card-body">
                                                            <div class="mb-4 container">
                                                                <h4 class="mb-0 text-inherit">Titulo</h4>
                                                                <input type="text" value="@if($data){{$data->propuesta2->titulo}}@endif" name="title2" class="form-control">
                                                            </div>
                                                            <hr class="mb-1">
                                                            <div class="mb-4 container">
                                                              <h4 class="mt-1 mb-0 text-inherit">Contenido</h4>
                                                            <textarea class="form-control" id="contenido" name="desc2" rows="8">@if($data){{$data->propuesta2->descripcion}}@endif</textarea>
                                                            </div>
                                                        </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-4 col-lg-6 mb-4">
                                            <div class="card h-100 p-1 shadow">
                                                <div class="card-body">
                                                    <div class="form-group">
                                                        <div class="mb-1">
                                                            <h4 class="text-inherit">Propuesta 3</h4>
                                                        </div>
                                                        <div class="button-right">
                                                            <h4>Visible </h4>
                                                            <div class="switch">
                                                                <input type="checkbox" @if($data) @if($data->propuesta3->visible) checked @endif @endif value="visible3" name="visible3" />
                                                                <div></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="hero__cta bc-img cursor-pointer" data-name="img3">
                                                        <img data-name="img3" src="@if($data){{$data->propuesta3->img}}@endif" class="cursor-pointer hero__cta img-fluid-2 rounded-top">
                                                    </div>
                                                        <div class="card-body">
                                                            <div class="mb-4 container">
                                                                <h4 class="mb-0 text-inherit">Titulo</h4>
                                                                <input type="text" value="@if($data){{$data->propuesta3->titulo}}@endif" name="title3" class="form-control">
                                                            </div>
                                                            <hr class="mb-1">
                                                            <div class="mb-4 container">
                                                              <h4 class="mt-1 mb-0 text-inherit">Contenido</h4>
                                                            <textarea class="form-control" id="contenido" name="desc3" rows="8">@if($data){{$data->propuesta3->descripcion}}@endif</textarea>
                                                            </div>
                                                        </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-4 col-lg-6 mb-4">
                                            <div class="card h-100 p-1 shadow">
                                                <div class="card-body">
                                                    <div class="form-group">
                                                        <div class="mb-1">
                                                            <label class="control-label">Propuesta 4</label>
                                                        </div>
                                                        <div class="button-right">
                                                            <h4>Visible </h4>
                                                            <div class="switch">
                                                                <input type="checkbox" @if($data) @if($data->propuesta4->visible) checked @endif @endif value="visible4" name="visible4" />
                                                                <div></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="hero__cta bc-img cursor-pointer" data-name="img4">
                                                        <img data-name="img4" src="@if($data){{$data->propuesta4->img}}@endif" class="cursor-pointer hero__cta img-fluid-2 rounded-top">
                                                    </div>
                                                        <div class="card-body">
                                                            <div class="mb-4 container">
                                                                <h4 class="mb-0 text-inherit">Titulo</h4>
                                                                <input type="text" value="@if($data){{$data->propuesta4->titulo}}@endif" name="title4" class="form-control">
                                                            </div>
                                                            <hr class="mb-1">
                                                            <div class="mb-4 container">
                                                              <h4 class="mt-1 mb-0 text-inherit">Contenido</h4>
                                                            <textarea class="form-control" id="contenido" name="desc4" rows="8">@if($data){{$data->propuesta4->descripcion}}@endif</textarea>
                                                            </div>
                                                        </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-4 col-lg-6 mb-4">
                                            <div class="card h-100 p-1 shadow">
                                                <div class="card-body">
                                                    <div class="form-group">
                                                        <div class="mb-1">
                                                            <label class="control-label">Propuesta 5</label>
                                                        </div>
                                                        <div class="button-right">
                                                            <h4>Visible </h4>
                                                            <div class="switch">
                                                                <input type="checkbox" @if($data) @if($data->propuesta5->visible) checked @endif @endif value="visible5" name="visible5" />
                                                                <div></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="hero__cta bc-img cursor-pointer" data-name="img5">
                                                        <img data-name="img5" src="@if($data){{$data->propuesta5->img}}@endif" class="cursor-pointer hero__cta img-fluid-2 rounded-top">
                                                    </div>
                                                        <div class="card-body">
                                                            <div class="mb-4 container">
                                                                <h4 class="mb-0 text-inherit">Titulo</h4>
                                                                <input type="text" value="@if($data){{$data->propuesta5->titulo}}@endif" name="title5" class="form-control">
                                                            </div>
                                                            <hr class="mb-1">
                                                            <div class="mb-4 container">
                                                              <h4 class="mt-1 mb-0 text-inherit">Contenido</h4>
                                                            <textarea class="form-control" id="contenido" name="desc5" rows="8">@if($data){{$data->propuesta5->descripcion}}@endif</textarea>
                                                            </div>
                                                        </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-4 col-lg-6 mb-4">
                                            <div class="card h-100 p-1 shadow">
                                                <div class="card-body">
                                                    <div class="form-group">
                                                        <div class="mb-1">
                                                            <label class="control-label">Propuesta 6</label>
                                                        </div>
                                                        <div class="button-right">
                                                            <h4>Visible </h4>
                                                            <div class="switch">
                                                                <input type="checkbox" @if($data) @if($data->propuesta6->visible) checked @endif @endif value="visible6" name="visible6" />
                                                                <div></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="hero__cta bc-img cursor-pointer" data-name="img6">
                                                        <img data-name="img6" src="@if($data){{$data->propuesta6->img}}@endif" class="cursor-pointer hero__cta img-fluid-2 rounded-top">
                                                    </div>
                                                        <div class="card-body">
                                                            <div class="mb-4 container">
                                                                <h4 class="mb-0 text-inherit">Titulo</h4>
                                                                <input type="text" value="@if($data){{$data->propuesta6->titulo}}@endif" name="title6" class="form-control">
                                                            </div>
                                                            <hr class="mb-1">
                                                            <div class="mb-4 container">
                                                              <h4 class="mt-1 mb-0 text-inherit">Contenido</h4>
                                                            <textarea class="form-control" id="contenido" name="desc6" rows="8">@if($data){{$data->propuesta6->descripcion}}@endif</textarea>
                                                            </div>
                                                        </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                            </div>
                        </div>
                    </div>
                    <input type="hidden" id="img1" value="@if($data){{$data->propuesta1->img}}@endif" name="img1">
                    <input type="hidden" id="img2" value="@if($data){{$data->propuesta2->img}}@endif" name="img2">
                    <input type="hidden" id="img3" value="@if($data){{$data->propuesta3->img}}@endif" name="img3">
                    <input type="hidden" id="img4" value="@if($data){{$data->propuesta4->img}}@endif" name="img4">
                    <input type="hidden" id="img5" value="@if($data){{$data->propuesta5->img}}@endif" name="img5">
                    <input type="hidden" id="img6" value="@if($data){{$data->propuesta6->img}}@endif" name="img6">
</form>


@endsection