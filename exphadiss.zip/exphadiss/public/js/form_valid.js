const formulario = document.getElementById('formulario');
const inputs = document.querySelectorAll('#form input');

const expresiones = {
	nombre: /^[a-zA-ZÀ-ÿ\s]{1,40}$/, // Letras y espacios, pueden llevar acentos.
	apellido: /^[a-zA-ZÀ-ÿ\s]{1,40}$/, // Letras y espacios, pueden llevar acentos.
	dni: /^\d{8,8}$/, // 7 a 14 numeros.
	correo: /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/,
	telefono: /^\d{7,9}$/ // 7 a 14 numeros.
}

const campos = {
	nombre: false,
	apellido: false,
	dni: false,
	correo: false,
	telefono: false
}

const validarFormulario = (e) => {
	switch (e.target.name) {
		case "nombre":
			validarCampo(expresiones.nombre, e.target, 'nombre');
		break;
		case "apellido":
			validarCampo(expresiones.apellido, e.target, 'apellido');
		break;
		case "dni":
			validarCampo(expresiones.dni, e.target, 'dni');
		break;
		case "correo":
			validarCampo(expresiones.correo, e.target, 'correo');
		break;
		case "telefono":
			validarCampo(expresiones.telefono, e.target, 'telefono');
		break;
	}
}

const validarCampo = (expresion, input, campo) => {
	if(expresion.test(input.value)){
		document.getElementById(`grupo__${campo}`).classList.remove('formulario__grupo-incorrecto');
		document.getElementById(`grupo__${campo}`).classList.add('formulario__grupo-correcto');
		document.querySelector(`#grupo__${campo} i`).classList.add('fa-check-circle');
		document.querySelector(`#grupo__${campo} i`).classList.remove('fa-times-circle');
		document.querySelector(`#grupo__${campo} .formulario__input-error`).classList.remove('formulario__input-error-activo');
		campos[campo] = true;
	} else {
		document.getElementById(`grupo__${campo}`).classList.add('formulario__grupo-incorrecto');
		document.getElementById(`grupo__${campo}`).classList.remove('formulario__grupo-correcto');
		document.querySelector(`#grupo__${campo} i`).classList.add('fa-times-circle');
		document.querySelector(`#grupo__${campo} i`).classList.remove('fa-check-circle');
		document.querySelector(`#grupo__${campo} .formulario__input-error`).classList.add('formulario__input-error-activo');
		campos[campo] = false;
	}
}


inputs.forEach((input) => {
	input.addEventListener('keyup', validarFormulario);
	input.addEventListener('blur', validarFormulario);
});

const btn = document.getElementById('button');

document.getElementById('form')
 .addEventListener('submit', function(event) {
   event.preventDefault();

   btn.value = 'Enviando Correo...';
   
   let data = {
	username : us,
	password : pas,
};
//let token;


fetch(url+'/api/security/login' ,{
	method:'post',
	headers: {
		'Accept': 'application/json',
		'Content-Type': 'application/json'
	  },
	body: JSON.stringify(data)
}).then(response => {
	
	if(+response.status === 200){
		return response.json();
	}else {
		alert(JSON.stringify(err));
	}
	
	return response.json();
}).then(data=>{
	//console.log(data);
	//this.token=data.token;
	
	let mail = {
		receiverAddress: correo_exphadis,
		subject: "Matrícula Exphadis",
		emailTemplate: 1,
		parameters: [
			nombre.value,
			apellido.value,
			dni.value,
			correo.value,
			telefono.value
		]
	};

	fetch(url+'/api/email',{
		method:'post',
		headers: {
			'Accept': 'application/json',
			'Content-Type': 'application/json',
			'Authorization': 'Bearer '+ data.token
		  },
		body: JSON.stringify(mail)
	}).then(response => {
		console.log(response);
		if(+response.status === 200){
			return response.json();
		}else {
			alert(JSON.stringify(err));
		}
		
	}).then(data => {

			btn.value = 'Enviar Correo';
			swal({
			  title: "Correo Enviado!",
			  text: "Nos Contactaremos contigo!",
			  icon: "success",
			  button: "Okey!",
			});
			this.reset();
		  }, (err) => {
			btn.value = 'Enviar Correo';
			alert(JSON.stringify(err));

	});
});



});
