<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

use Mail;
use App\Mail\MailNotify;

class BaseController extends Controller
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;
    
    public function index(Request $request)
    {
        $page = DB::table('paginas')->where([['id','=',1]])->first();

        if($page->bool=='true'){

            return $this->matricula($request);
        }
        
        $horariowp = DB::table('content')->where([['id','=',1]])->first();
        $data = [
            'horarios' => $horariowp
        ];

        $nosotros = DB::table('content')->where([['id','=',4]])->first();
        $data['nosotros'] = $nosotros;
        

        $anuncioswp = DB::table('content')->where([['id','=',8]])->first();
        $data['anuncios_options'] = json_decode($anuncioswp->content_optional);
        $data['anuncioswp_subtitle'] = $anuncioswp->sub_title;
        $data['anuncioswp_subtitle_2'] = $anuncioswp->sub_title_2;
        $data['anuncioswp_cont'] = $anuncioswp->description;

        $googlemaps = DB::table('content')->where([['id','=',15]])->first();
        $data['googlemaps'] = $googlemaps;
        
        $paginacion = DB::table('paginas')->where([['id',"=",1]])->first();
        $seccion = DB::table('seccion')->where([['id','=',2]])->first();
        $content = DB::table('content')->where([['id','=',$seccion->content_id]])->first();
        $data['menu'] = json_decode($content->content_optional);
        
        $pilar = DB::table('content')->where([['id','=',5]])->first();
        $data['pilar'] = json_decode($pilar->content_optional);
        $data['title'] = $pilar->title_seccion;
        $data['subtitle']= $pilar->sub_title;
        

        $prop = DB::table('content')->where([['id','=',6]])->first();
        $data['propuesta'] = json_decode($prop->content_optional);

        $admin = DB::table('content')->where([['id','=',17]])->first();
        $data['admin'] = json_decode($admin->content_optional);

        $banner = DB::table('content')->where([['id','=',3]])->first();
        $data['time']=$banner->description;
        $banner=$banner->content_optional;
        $data['banner'] = json_decode($banner);
        $data['bannercount'] = count($data['banner']);

        $banner = DB::table('content')->where([['id','=',7]])->first();
        $data['galeria'] = json_decode($banner->content_optional);
        $data['titulo'] = $banner->title_seccion;

        $data['redes'] = DB::table('redes')->get();

        $contac = DB::table('content')->where([['id','=',14]])->first();
        $data['contacto'] = json_decode($contac->content_optional);

        return view('index',$data);
    }

    public function matricula(Request $request)
    {
        $seccion = DB::table('seccion')->where([['id','=',2]])->first();
        $content = DB::table('content')->where([['id','=',$seccion->content_id]])->first();
        $context = json_decode($content->content_optional);
        if($context->matricula->visible==false){
            return redirect('/');
        }
        
        $seccion = DB::table('seccion')->where([['id','=',9]])->first();
        $content = DB::table('content')->where([['id','=',$seccion->content_id]])->first();
        $data['menu'] = json_decode($content->content_optional);

        $bannerwm = DB::table('content')->where([['id','=',10]])->first();
        $data['bannerwm_options'] = json_decode($bannerwm->content_optional);
        $data['bannerwm_title'] = $bannerwm->title_seccion;
        $data['bannerwm_subtitle'] = $bannerwm->sub_title;
        $data['bannerwm_cont'] = $bannerwm->description;


        $content = DB::table('content')->where([['id','=',13]])->first();
        $data['sub_titulomw'] = $content->sub_title;
        $data['titulomw'] = $content->title_seccion;
        $data['matriculawmcont'] = json_decode($content->content_optional);

        $formu = DB::table('content')->where([['id','=',16]])->first();
        $data['formulariowm'] = $formu;

        $googlemaps = DB::table('content')->where([['id','=',15]])->first();
        $data['googlemaps'] = $googlemaps;
        
        $contac = DB::table('content')->where([['id','=',14]])->first();
        $data['contacto'] = json_decode($contac->content_optional);

        $data['redes'] = DB::table('redes')->get();

        $adminmatricula = DB::table('content')->where([['id','=',17]])->first();
        $data['adminmatricula'] = json_decode($adminmatricula->content_optional);

        return view('matricula',$data);

        

    }
    public function login(Request $request)
    {
        $data = ['error'=>false];
        if($request->isMethod('post')){
            // asi inicias sesion 
            $user = $request->usuario;
            $pass = $request->password;
            $usuario = DB::table('usuarios')->where([['usuario','=',$user],['password','=',md5($pass)]])->first();/*md5($pass)*/
            if(!$usuario){
                $data['error'] = true;
            }else{
                $request->session()->put('loged',true);
                // aca guardas la sesion como true 
                return redirect('/admin');
            }
        }
        return view('login',$data);
    }
    public function logout(Request $request)
    {
        $request->session()->flush();
        return redirect('/signin');
    }
}

