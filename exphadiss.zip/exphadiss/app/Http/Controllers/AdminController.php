<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Crypt;

class AdminController extends Controller
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function admin(Request $request)
    {   
        // asi protejes la ruta para que tengan que loguearse
        if(!$request->session()->has('loged')){
            return redirect('/signin');
        }

        $context = ['data'=>null];
        if ($request->isMethod('post')) {
            $admin = [
               'horario' => [
                    'visible' => $request->has('horariocheck')
                ],

                'menu' => [
                    'visible' => $request->has('menucheck')
                ],

                'banner' => [
                    'visible' => $request->has('bannercheck')
                ],

                'nosotros' => [
                    'visible' => $request->has('nosotroscheck')
                ],

                'pilares' => [
                    'visible' => $request->has('pilarescheck')
                ],

                'propuesta' => [
                    'visible' => $request->has('propuestacheck')
                ],
                'galeria' => [
                    'visible' => $request->has('galeriacheck')
                ],

                'anuncios' => [
                    'visible' => $request->has('anuncioscheck')
                ],

                'googlemaps' => [
                    'visible' => $request->has('googlemapscheck')
                ],

                'contacto' => [
                    'visible' => $request->has('contactocheck')
                ],

                'menumatricula' => [
                    'visible' => $request->has('menumatriculacheck')
                ],

                'bannermatricula' => [
                    'visible' => $request->has('bannermatriculacheck')
                ],
                'opcionesmatricula' => [
                    'visible' => $request->has('opcionesmatriculacheck')
                ],

                'formulariomatricula' => [
                    'visible' => $request->has('formulariomatriculacheck')
                ],
                'googlemapsmatricula' => [
                    'visible' => $request->has('googlemapsmatricula')
                ],
                'contactomatricula' => [
                    'visible' => $request->has('contactomatricula')
                ]
            ];
            DB::table('content')->where([['id','=',17]])->update([
                'content_optional' =>  json_encode($admin)
            ]);
            return redirect('/admin');
        }else{
            $context['data'] = DB::table('content')->where([['id','=',17]])->first();
            if($context['data']){
                $context['data'] = json_decode($context['data']->content_optional);
            }
        }
        
        return view('admin',$context);
    }
    public function horariowp(Request $request)
    {
        $context = [];
        if ($request->isMethod('post')) {
            $seccion = DB::table('seccion')->where([['id','=',1]])->first();
            $content = DB::table('content')->where([['id','=',$seccion->content_id]])->update(
                [
                    'content_optional' => $request->titulo

                ]
            );
            return redirect('/horariowp');
        }else{
            $seccion = DB::table('seccion')->where([['id','=',1]])->first();
            $content = DB::table('content')->where([['id','=',$seccion->content_id]])->first();
            $context['data'] = $content;
        }

        return view('horariowp',$context);
    }
    public function menuwp(Request $request)
    {
        $context = [];
        if ($request->isMethod('post')) {
            $seccion = DB::table('seccion')->where([['id','=',2]])->first();
            $content = DB::table('content')->where([['id','=',$seccion->content_id]])->update(
                [
                    'content_optional' => json_encode([
                        'inicio'=>[
                            'nombre'=>$request->inicio,
                            'img'=>$request->imglogo,
                            'visible'=>$request->has('c1'),
                            'url'=>$request->link1
                        ],
                        'matricula'=>[
                            'nombre'=>$request->matricula,
                            'visible'=>$request->has('c2'),
                            'url'=>$request->link2
                        ],
                        'nosotros'=>[
                            'nombre'=>$request->nosotros,
                            'visible'=>$request->has('c3'),
                            'url'=>$request->link3
                        ],
                        'propuesta'=>[
                            'nombre'=>$request->propuesta,
                            'visible'=>$request->has('c4'),
                            'url'=>$request->link4
                        ],
                        'contacto'=>[
                            'nombre'=>$request->contacto,
                            'visible'=>$request->has('c5'),
                            'url'=>$request->link5
                        ]
                    ])

                ]
            );
            
            return redirect('/menuwp');
        }else{
            $seccion = DB::table('seccion')->where([['id','=',2]])->first();
            $content = DB::table('content')->where([['id','=',$seccion->content_id]])->first();
            $context['data'] = json_decode($content->content_optional);
        }

        return view('menuwp',$context);
    }
    public function bannerwp(Request $request)
    {
        $context = ['banners' =>'[]'];
        $time = ['time_banners' => null];
        if ($request->isMethod('post')) {
            DB::table('content')->where([['id','=',3]])->update([
                'description' => $request->time_banners,
                'content_optional' => $request->dataenv
            ]);
            return redirect('/bannerwp');
        }else{
            $context['banners'] = DB::table('content')->where([['id','=',3]])->first();
            $context['time_banners']=$context['banners']->description;
            $context['banners']=$context['banners']->content_optional;
        }

        return view('bannerwp',$context);
    }
    public function nosotroswp(Request $request)
    {
        $nosotros = [];
        if ($request->isMethod('post')) {
            $seccion = DB::table('seccion')->where([['id','=',4]])->first();
            $content = DB::table('content')->where([['id','=',$seccion->content_id]])->update(
                [
                    'title_seccion' => $request->titulo,
                    'sub_title' => $request->sub_titulo_1,
                    'sub_title_2' => $request->sub_titulo_2,
                    'description' => $request->contenido,
                    'content_optional' => $request->imagennosotros

                ]
            );
            return redirect('/nosotroswp');
        }else{
            $seccion = DB::table('seccion')->where([['id','=',4]])->first();
            $content = DB::table('content')->where([['id','=',$seccion->content_id]])->first();
            $nosotros['data'] = $content;
        }

        return view('nosotroswp',$nosotros);
        
    }
    public function pilareswp(Request $request)
    {
        $context = ['data'=>null];
        if ($request->isMethod('post')) {
            //return response()->json($request);
            
            $pilar = [
               'pilar1' => [
                    'titulo'=> $request->title1,
                    'descripcion' => $request->desc1,
                    'img' => $request->img1,
                    'visible' => $request->has('visible1'),
                    'clase' => $request->clase1
                ],

                'pilar2' => [
                    'titulo'=> $request->title2,
                    'descripcion' => $request->desc2,
                    'img' => $request->img2,
                    'visible' => $request->has('visible2'),
                    'clase' => $request->clase2
                ],

                'pilar3' => [
                    'titulo'=> $request->title3,
                    'descripcion' => $request->desc3,
                    'img' => $request->img3,
                    'visible' => $request->has('visible3'),
                    'clase' => $request->clase3
                ],

                'pilar4' => [
                    'titulo'=> $request->title4,
                    'descripcion' => $request->desc4,
                    'img' => $request->img4,
                    'visible' => $request->has('visible4'),
                    'clase' => $request->clase4
                ]
            ];
            DB::table('content')->where([['id','=',5]])->update([
                    'title_seccion' => $request-> title_pilares,
                    'sub_title' => $request-> sub_title_pilares,
                    'content_optional' =>  json_encode($pilar)
            ]);
            return redirect('/pilareswp');
        }else{
            $context['data'] = DB::table('content')->where([['id','=',5]])->first();
            if($context['data']){
                $coasd = $context['data'];
                $context['data'] = json_decode($context['data']->content_optional);
                $context['data']->sub_title = $coasd->sub_title;
                $context['data']->title_seccion = $coasd->title_seccion;
            }
        }

        return view('pilareswp',$context);
    }
    public function propuestawp(Request $request)
    {
        $context = ['data'=>null];
        if ($request->isMethod('post')) {
            //return response()->json($request);
            $propues = [
                'propuesta' => [
                    'titulo'=> $request->title,
                ],
               'propuesta1' => [
                    'titulo'=> $request->title1,
                    'descripcion' => $request->desc1,
                    'img' => $request->img1,
                    'visible' => $request->has('visible1')
                ],

                'propuesta2' => [
                    'titulo'=> $request->title2,
                    'descripcion' => $request->desc2,
                    'img' => $request->img2,
                    'visible' => $request->has('visible2')
                ],

                'propuesta3' => [
                    'titulo'=> $request->title3,
                    'descripcion' => $request->desc3,
                    'img' => $request->img3,
                    'visible' => $request->has('visible3')
                ],

                'propuesta4' => [
                    'titulo'=> $request->title4,
                    'descripcion' => $request->desc4,
                    'img' => $request->img4,
                    'visible' => $request->has('visible4')
                ],

                'propuesta5' => [
                    'titulo'=> $request->title5,
                    'descripcion' => $request->desc5,
                    'img' => $request->img5,
                    'visible' => $request->has('visible5')
                ],

                'propuesta6' => [
                    'titulo'=> $request->title6,
                    'descripcion' => $request->desc6,
                    'img' => $request->img6,
                    'visible' => $request->has('visible6')
                ]
            ];
            DB::table('content')->where([['id','=',6]])->update([
                'content_optional' =>  json_encode($propues)
            ]);
            return redirect('/propuestawp');
        }else{
            $context['data'] = DB::table('content')->where([['id','=',6]])->first();
            if($context['data']){
                $context['data'] = json_decode($context['data']->content_optional);
            }
        }

        return view('propuestawp',$context);
    }
    public function galeria(Request $request)
    {
        $context = ['data'=>null];
        $titulo = ['titulo'=>null];
        if ($request->isMethod('post')) {
            DB::table('content')->where([['id','=',7]])->update([
                'title_seccion' => $request->title_galeria_exphadis,
                'content_optional' =>  $request->data
            ]);
            return redirect('/galeria');
        }else{
            $context['data'] = DB::table('content')->where([['id','=',7]])->first();
            if($context['data']){
                $context['titulo']= $context['data']->title_seccion;
                $context['data'] = $context['data']->content_optional;
                
            }
        }

        return view('galeria',$context);
    }
    public function googlemaps(Request $request)
    {
        $context = [];
        if ($request->isMethod('post')) {
            $seccion = DB::table('seccion')->where([['id','=',15]])->first();
            $content = DB::table('content')->where([['id','=',$seccion->content_id]])->update(
                [
                    'content_optional' => $request->googlemaps

                ]
            );
            return redirect('/googlemaps');
        }else{
            $seccion = DB::table('seccion')->where([['id','=',15]])->first();
            $content = DB::table('content')->where([['id','=',$seccion->content_id]])->first();
            $context['data'] = $content;
        }

        return view('googlemaps',$context);
    }
    public function contacto(Request $request)
    {
        $context = ['data'=>null];
        if ($request->isMethod('post')) {
            //return response()->json($request);
            $contacto = [
                'copy' => [
                    'copy_content'=> $request->copy_content,
                ],
               'niveles' => [
                    'nivel1'=> $request->nivel1,
                    'nivel2' => $request->nivel2,
                    'nivel3' => $request->nivel3
                ],

                'visitanos' => [
                    'ubicacion' => $request->ubicacion
                ],

                'telefonica' => [
                    'num1'=> $request->num1,
                    'num2' => $request->num2
                ]
            ];
            DB::table('content')->where([['id','=',14]])->update([
                'content_optional' =>  json_encode($contacto)
            ]);
            return redirect('/contacto');
        }else{
            $context['data'] = DB::table('content')->where([['id','=',14]])->first();
            if($context['data']){
                $context['data'] = json_decode($context['data']->content_optional);
            }
        }

        return view('contacto',$context);
    }
    public function anuncioswp(Request $request)
    {
        $anuncioswp = ['data'=>null];
        if ($request->isMethod('post')) {
            $cont_anun = [
               'boton' => [
                    'nombre'=> $request->name_boton_anun,
                    'link' => $request->link_anun,
                    'visible' => $request->has('visi_anun')
                ],
                'img_anuncios' => [
                    'img'=> $request->imagenanuncios
                ]
            ];
            DB::table('content')->where([['id','=',8]])->update([
                    'sub_title' => $request->sub_titulo_1,
                    'sub_title_2' => $request->sub_titulo_2,
                    'description' => $request->contenido,
                    'content_optional' =>  json_encode($cont_anun)
            ]);
            return redirect('/anuncioswp');
        }else{
            $anuncioswp['data'] = DB::table('content')->where([['id','=',8]])->first();
            if($anuncioswp['data']){
                $datos = $anuncioswp['data'];
                $anuncioswp['data'] = json_decode($anuncioswp['data']->content_optional);
                $anuncioswp['data']->sub_title = $datos->sub_title;
                $anuncioswp['data']->sub_title_2 = $datos->sub_title_2;
                $anuncioswp['data']->description = $datos->description;
            }
        }

        return view('anuncioswp',$anuncioswp);
    }
    public function redes(Request $request)
    {

        $context = ['data'=>null];
        if ($request->isMethod('post')) {
            DB::table('redes')->where([['id','=',1]])->update([
                'link_redes' => $request->link_redes_w,
                'bool' => $request->has('redescheck'),
                'clase' => $request->class_w,
                'clase1' => $request->class_w1,
                'clase2' => $request->class_w2
            ]);

            
            DB::table('redes')->where([['id','=',2]])->update([
                'link_redes' => $request->link_redes_f,
                'bool' => $request->has('redescheck1'),
                'clase' => $request->class_f,
                'clase1' => $request->class_f1,
                'clase2' => $request->class_f2
            ]);

            DB::table('redes')->where([['id','=',3]])->update([
                'link_redes' => $request->link_redes_m,
                'bool' => $request->has('redescheck2'),
                'clase' => $request->class_m,
                'clase1' => $request->class_m1,
                'clase2' => $request->class_m2
            ]);

            DB::table('redes')->where([['id','=',4]])->update([
                'link_redes' => $request->link_redes_i,
                'bool' => $request->has('redescheck3'),
                'clase' => $request->class_i,
                'clase1' => $request->class_i1,
                'clase2' => $request->class_i2
            ]);

            DB::table('redes')->where([['id','=',5]])->update([
                'link_redes' => $request->link_redes_y,
                'bool' => $request->has('redescheck4'),
                'clase' => $request->class_y,
                'clase1' => $request->class_y1,
                'clase2' => $request->class_y2
            ]);

            DB::table('redes')->where([['id','=',6]])->update([
                'link_redes' => $request->link_redes_g,
                'bool' => $request->has('redescheck5'),
                'clase' => $request->class_g,
                'clase1' => $request->class_g1,
                'clase2' => $request->class_g2
            ]);

            return redirect('/redes');
        }else{
            $context['data'] = DB::table('redes')->get();
        }

        return view('redes',$context);
    }
    public function profile(Request $request)
    {
        $profile_admin = [];
        if ($request->isMethod('post')) {

            $pass = md5($request->pass);
            
            $seccion = DB::table('usuarios')->where([['id','=',1]])->update(
                [
                    'usuario' => $request->user,
                    'password' => $pass,
                    'img_admin' => $request->img_profile_admin
                ]
            );
            return redirect('/profile');
        }else{
            $seccion = DB::table('usuarios')->where([['id','=',1]])->first();
            $profile_admin['data'] = $seccion;
        }

        return view('profile',$profile_admin);
    }
    /*==========WEB MATRICULA===========*/
    public function menuwm(Request $request)
    {
        $context = [];
        if ($request->isMethod('post')) {
            $seccion = DB::table('seccion')->where([['id','=',9]])->first();
            $content = DB::table('content')->where([['id','=',$seccion->content_id]])->update(
                [
                    'content_optional' => json_encode([
                        'admision'=>[
                            'nombre'=>$request->admision,
                            'img'=>$request->imglogowm,
                            'visible'=>$request->has('m1'),
                            'url'=>$request->linkm1
                        ],
                        'tutoriales'=>[
                            'nombre'=>$request->tutoriales,
                            'visible'=>$request->has('m2'),
                            'url'=>$request->linkm2
                        ],
                        'contactanos'=>[
                            'nombre'=>$request->contactanos,
                            'visible'=>$request->has('m3'),
                            'url'=>$request->linkm3
                        ]
                    ])

                ]
            );
            
            return redirect('/menuwm');
        }else{
            $seccion = DB::table('seccion')->where([['id','=',9]])->first();
            $content = DB::table('content')->where([['id','=',$seccion->content_id]])->first();
            $context['data'] = json_decode($content->content_optional);
        }

        return view('menuwm',$context);
    }
    public function bannerwm(Request $request)
    {
        $bannerwm = [];
        if ($request->isMethod('post')) {
            $cont_ban_wm = [
               'boton' => [
                    'nombre'=> $request->text_btn1_banner,
                    'link' => $request->link_btn1_banner,
                    'visible' => $request->has('bannercheck1')
                ],
                'img_bannerwm' => [
                    'img'=> $request->banner_imagen_wm
                ]
            ];
            DB::table('content')->where([['id','=',10]])->update([
                    'title_seccion' => $request->titulo_banner_wm,
                    'sub_title' => $request->subtitulo_banner_wm,
                    'description' => $request->contenido_wm_banner,
                    'content_optional' =>  json_encode($cont_ban_wm)
            ]);
            return redirect('/bannerwm');
        }else{
            $bannerwm['data'] = DB::table('content')->where([['id','=',10]])->first();
            if($bannerwm['data']){
                $datosbanwm = $bannerwm['data'];
                $bannerwm['data'] = json_decode($bannerwm['data']->content_optional);
                $bannerwm['data']->title_seccion = $datosbanwm->title_seccion;
                $bannerwm['data']->sub_title = $datosbanwm->sub_title;
                $bannerwm['data']->description = $datosbanwm->description;
            }
        }

        return view('bannerwm',$bannerwm);
    }
    public function matriculawm(Request $request)
    {
        $context_matri = ['data'=>null];
        $titulo = ['titulo'=>null];
        $subtitu = ['subtitu'=>null];
        if ($request->isMethod('post')) {
            DB::table('content')->where([['id','=',13]])->update([
                'title_seccion' => $request->titulo_matricula_cont,
                'sub_title' => $request->sub_titulo_matricula_cont,
                'content_optional' =>  $request->input('datitos')
            ]);
            return redirect('/matriculawm');
        }else{
            $context_matri['data'] = DB::table('content')->where([['id','=',13]])->first();
            if($context_matri['data']){
                $context_matri['subtitu']= $context_matri['data']->sub_title;
                $context_matri['titulo']= $context_matri['data']->title_seccion;
                $context_matri['data'] = $context_matri['data']->content_optional;
            }
        }
        return view('matriculawm',$context_matri);
    }
    public function formulariowm(Request $request)
    {
        $formulariowm_content = [];
        if ($request->isMethod('post')) {
            $seccion = DB::table('seccion')->where([['id','=',16]])->first();
            $content = DB::table('content')->where([['id','=',$seccion->content_id]])->update(
                [
                    'title_seccion' => $request->tituloform,
                    'sub_title' => $request->sub_tituloform,
                    'content_optional' => $request->correo

                ]
            );
            return redirect('/formulariowm');
        }else{
            $seccion = DB::table('seccion')->where([['id','=',16]])->first();
            $content = DB::table('content')->where([['id','=',$seccion->content_id]])->first();
            $formulariowm_content['data'] = $content;
        }

        return view('formulariowm',$formulariowm_content);
    }
    /*==============INSERTAR PROPUESTA===============*/
    public function insertarpropuesta(Request $request)
    {
        return view('insertarpropuesta');
    }
    public function galeriafotos(Request $request)
    {
        return view('galeriafotos');
    }
    /*===============================================*/
    public function subirimg(Request $request)
    {
        if($request->bajar){
            $data = DB::table('mediaoption')->get(['id','url_media']);
            return response()->json(['ok'=>true,'items'=>$data]);
        }else{
            DB::table('mediaoption')->insert([
                'name_media'=>$request->url,
                'type_media'=>'img',
                'url_media'=>$request->url
            ]);
        }

        return response()->json(['ok'=>true,'url'=>$request->url]);
    }
    /*SUBIR Y CARGAR IMAGENES*/
    public function subirimagen(Request $request)
    {
        $data = DB::table('mediaoption')->get(['url_media']);
        $context = ['data'=>$data];
        return view('subirimagen',$context);
    }
    public function changetype(Request $request)
    {   
        if(!$request->session()->has('loged')){
            return response()->json(['ok'=>false]);
        }

        DB::table('paginas')->where([['id','=',1]])->update(['bool'=>$request->check]);
        
        return response()->json(['ok'=>true]);
    }




    public function Elimng(Request $request)
    {
        DB::table('mediaoption')->where([['id','=',$request->id]])->delete();
        return response()->json(['ok'=>true]);
    }

}
