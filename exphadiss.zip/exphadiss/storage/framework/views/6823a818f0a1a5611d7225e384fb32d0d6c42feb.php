
<?php $__env->startSection('content'); ?>
<form method="post">
    <div class="card">
                        <div class="card-body p-1">
                            <h4 class="text-inherit">Pilares Web Principal</h4>
                            <?php echo csrf_field(); ?>
                            <button class="button_editar button-right" type="submit">Guardar</button>
                            <hr class="mt-2">
                            <div class="container-fluid">
                            <div class="row">
                                        <div class="col-lg-6 mt-2 mb-4">
                                            <div class="card h-100 p-1 shadow">
                                                <div class="card-body">
                                                    <h4 class="text-inherit">Titulo</h4>
                                                    <input type="text" <?php if($data && $data->title_seccion): ?> value="<?php echo e($data->title_seccion); ?>" <?php endif; ?> name="title_pilares" class="form-control" >
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 mt-2 mb-4">
                                            <div class="card h-100 p-1 shadow">
                                                <div class="card-body">
                                                    <h4 class="text-inherit">Subtitulo</h4>
                                                    <input type="text" <?php if($data && $data->sub_title): ?> value="<?php echo e($data->sub_title); ?>" <?php endif; ?> name="sub_title_pilares" class="form-control" >
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-4 col-lg-6 mb-4">
                                            <div class="card h-100 p-1 shadow">
                                                <div class="card-body">
                                                    <div class="form-group">
                                                        <div class="mb-1">
                                                            <h4 class="text-inherit">Pilar 1</h4>
                                                            <input type="hidden" name="clase1" value="<?php if($data): ?><?php echo e($data->pilar1->clase); ?><?php endif; ?>">
                                                        </div>
                                                        <div class="button-right">
                                                            <h4>Visible </h4>
                                                            <div class="switch">
                                                                <input type="checkbox" value="visible1" <?php if($data): ?> <?php if($data->pilar1->visible): ?> checked <?php endif; ?> <?php endif; ?> name="visible1" />
                                                                <div></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                        <img data-name="img1" src="<?php if($data): ?><?php echo e($data->pilar1->img); ?><?php endif; ?>" class="bc-default hero__cta img-fluid rounded-top">
                                                        <div class="card-body">
                                                            <div class="mb-4 container">
                                                                <h4 class="mb-0 text-inherit">Titulo</h4>
                                                                <input type="text" value="<?php if($data): ?><?php echo e($data->pilar1->titulo); ?><?php endif; ?>" name="title1" class="form-control">
                                                            </div>
                                                            <hr class="mb-1">
                                                            <div class="mb-4 container">
                                                              <h4 class="mt-1 mb-0 text-inherit">Contenido</h4>
                                                            <textarea class="form-control" id="contenido" name="desc1" rows="8"><?php if($data): ?><?php echo e($data->pilar1->descripcion); ?><?php endif; ?></textarea>
                                                            </div>
                                                        </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-4 col-lg-6 mb-4">
                                            <div class="card h-100 p-1 shadow">
                                                <div class="card-body">
                                                    <div class="form-group">
                                                        <div class="mb-1">
                                                            <h4 class="text-inherit">Pilar 2</h4>
                                                            <input type="hidden" name="clase2" value="<?php if($data): ?><?php echo e($data->pilar2->clase); ?><?php endif; ?>">
                                                        </div>
                                                        <div class="button-right">
                                                            <h4>Visible </h4>
                                                            <div class="switch">
                                                                <input type="checkbox" <?php if($data): ?> <?php if($data->pilar2->visible): ?> checked <?php endif; ?> <?php endif; ?> value="visible2" name="visible2" />
                                                                <div></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                        <img data-name="img2" src="<?php if($data): ?><?php echo e($data->pilar2->img); ?><?php endif; ?>" class="bc-default hero__cta img-fluid rounded-top">
                                                        <div class="card-body">
                                                            <div class="mb-4 container">
                                                                <h4 class="mb-0 text-inherit">Titulo</h4>
                                                                <input type="text" value="<?php if($data): ?><?php echo e($data->pilar2->titulo); ?><?php endif; ?>" name="title2" class="form-control">
                                                            </div>
                                                            <hr class="mb-1">
                                                            <div class="mb-4 container">
                                                              <h4 class="mt-1 mb-0 text-inherit">Contenido</h4>
                                                            <textarea class="form-control" id="contenido" name="desc2" rows="8"><?php if($data): ?><?php echo e($data->pilar2->descripcion); ?><?php endif; ?></textarea>
                                                            </div>
                                                        </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-4 col-lg-6 mb-4">
                                            <div class="card h-100 p-1 shadow">
                                                <div class="card-body">
                                                    <div class="form-group">
                                                        <div class="mb-1">
                                                            <h4 class="text-inherit">Pilar 3</h4>
                                                            <input type="hidden" name="clase3" value="<?php if($data): ?><?php echo e($data->pilar3->clase); ?><?php endif; ?>">
                                                        </div>
                                                        <div class="button-right">
                                                            <h4>Visible </h4>
                                                            <div class="switch">
                                                                <input type="checkbox" <?php if($data): ?> <?php if($data->pilar3->visible): ?> checked <?php endif; ?> <?php endif; ?> value="visible3" name="visible3" />
                                                                <div></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                        <img data-name="img3" src="<?php if($data): ?><?php echo e($data->pilar3->img); ?><?php endif; ?>" class="bc-default hero__cta img-fluid rounded-top">
                                                        <div class="card-body">
                                                            <div class="mb-4 container">
                                                                <h4 class="mb-0 text-inherit">Titulo</h4>
                                                                <input type="text" value="<?php if($data): ?><?php echo e($data->pilar3->titulo); ?><?php endif; ?>" name="title3" class="form-control">
                                                            </div>
                                                            <hr class="mb-1">
                                                            <div class="mb-4 container">
                                                              <h4 class="mt-1 mb-0 text-inherit">Contenido</h4>
                                                            <textarea class="form-control" id="contenido" name="desc3" rows="8"><?php if($data): ?><?php echo e($data->pilar3->descripcion); ?><?php endif; ?></textarea>
                                                            </div>
                                                        </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-4 col-lg-6 mb-4">
                                            <div class="card h-100 p-1 shadow">
                                                <div class="card-body">
                                                    <div class="form-group">
                                                        <div class="mb-1">
                                                            <h4 class="text-inherit">Pilar 4</h4>
                                                            <input type="hidden" name="clase4" value="<?php if($data): ?><?php echo e($data->pilar4->clase); ?><?php endif; ?>">
                                                        </div>
                                                        <div class="button-right">
                                                            <h4>Visible </h4>
                                                            <div class="switch">
                                                                <input type="checkbox" <?php if($data): ?> <?php if($data->pilar4->visible): ?> checked <?php endif; ?> <?php endif; ?> value="visible4" name="visible4" />
                                                                <div></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                        <img data-name="img4" src="<?php if($data): ?><?php echo e($data->pilar4->img); ?><?php endif; ?>" class="bc-default hero__cta img-fluid rounded-top">
                                                        <div class="card-body">
                                                            <div class="mb-4 container">
                                                                <h4 class="mb-0 text-inherit">Titulo</h4>
                                                                <input type="text" value="<?php if($data): ?><?php echo e($data->pilar4->titulo); ?><?php endif; ?>" name="title4" class="form-control">
                                                            </div>
                                                            <hr class="mb-1">
                                                            <div class="mb-4 container">
                                                              <h4 class="mt-1 mb-0 text-inherit">Contenido</h4>
                                                            <textarea class="form-control" id="contenido" name="desc4" rows="8"><?php if($data): ?><?php echo e($data->pilar4->descripcion); ?><?php endif; ?></textarea>
                                                            </div>
                                                        </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                            </div>
                        </div>
                    </div>
                    <input type="hidden" id="img1" value="<?php if($data): ?><?php echo e($data->pilar1->img); ?><?php endif; ?>" name="img1">
                    <input type="hidden" id="img2" value="<?php if($data): ?><?php echo e($data->pilar2->img); ?><?php endif; ?>" name="img2">
                    <input type="hidden" id="img3" value="<?php if($data): ?><?php echo e($data->pilar3->img); ?><?php endif; ?>" name="img3">
                    <input type="hidden" id="img4" value="<?php if($data): ?><?php echo e($data->pilar4->img); ?><?php endif; ?>" name="img4">
</form>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Leo\Desktop\exphadiss\resources\views/pilareswp.blade.php ENDPATH**/ ?>