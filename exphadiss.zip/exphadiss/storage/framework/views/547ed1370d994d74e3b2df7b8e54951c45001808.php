
<?php $__env->startSection('content'); ?>
<script>
    async function eliminarFotitoChida(e){
        let  si  = await swal("¿Seguro que desea eliminar esta Imagen?", {
        icon: "warning" ,
        dangerMode: true,
        buttons: true,
        });

        if(si){
            fetch('/eliminarImagen?id='+e.target.dataset.id).then(res=>{
                res = res.json();
                if(res.ok){
                    
                    
                    // aca se elimina de firebase


                    document.querySelector('.img_gallery_fotos_general'+e.target.dataset.id).remove();
                    e.target.remove();
                }
                window.location.reload();
            }).catch(async err=>{
                await swal({
                title: "Ha ocurrido un error al Eliminar la imagen",
                });
         
                window.location.reload(); 
            })
        }
    }
</script>
                    <div class="card">
                        <form method="post">
                            <div class="card-body p-1">
                            <h4 class="text-inherit">Galeria de Fotos</h4>
                            <?php echo csrf_field(); ?>
                            <button class="button_editar hero__cta_subir button-right" id="">Subir Imagen<i class=""></i></button>
                            
                                <div class="container-fluid mt-2">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="">
                                                <div class="mostrar-imagen-exphadis2 bc-default">
                                                    <div class="" style="display:flex; flex-wrap: wrap;">

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <?php echo csrf_field(); ?>
                                        <!--<button class="button_editar mt-2 w-100" type="submit">Guardar</button>-->
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Leo\Desktop\exphadiss\resources\views/galeriafotos.blade.php ENDPATH**/ ?>