
<?php $__env->startSection('content'); ?>

<form method="post">
                    <div class="card container-fluid">
                        <div class="card-body p-1">
                            <h4 for="menu" class="text-inherit">Perfil Admin</h4>
                                     <?php echo csrf_field(); ?>
                                    <button class="button_editar button-right" type="submit">Guardar</button>
                            <hr class="mt-2 mb-2">
                                <div class="container-fluid">
                                    <div class="row">
                                    
                                        <div class="col-xl-4 col-lg-6 mb-4">
                                            <div class="card h-100 p-2 shadow">
                                            <h4 class="text-inherit">Usuario</h4>
                                            <hr>
                                            <input type="text" <?php if($data && $data->usuario): ?> value="<?php echo e($data->usuario); ?>" <?php endif; ?> name="user" class="form-control" placeholder="exphadis">
                                            <h4 class="text-inherit mt-1">Contraseña Cifrada</h4>
                                            <hr>
                                            <input type="text" <?php if($data && $data->password): ?> value="<?php echo e($data->password); ?>" <?php endif; ?> class="form-control" disabled>
                                            <h4 class="text-inherit mt-1">Cambiar Contraseña</h4>
                                            <hr>
                                            <input type="text" name="pass" class="form-control">
                                            
                                            </div>
                                        </div>
                                        <div class="col-xl-4 col-lg-6 mb-4">
                                            <div class="card h-100 p-2 shadow">
                                            <h4 class="text-inherit">Perfil Admin</h4>
                                            <img data-name="img_profile_admin" class="hero__cta shadow bc-img cursor-pointer img-fluid" name="img_profile_admin" src="<?php if($data): ?><?php echo e($data->img_admin); ?><?php endif; ?>">
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            
                        </div>
                    </div>
                    <input type="hidden" id="img_profile_admin" value="<?php if($data): ?><?php echo e($data->img_admin); ?><?php endif; ?>" name="img_profile_admin">
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Leo\Desktop\exphadiss\resources\views/profile.blade.php ENDPATH**/ ?>