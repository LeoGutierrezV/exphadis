<?php
  $APP_ENV= env('APP_ENV');
  $apiKey = env('FIREBASE_API_KEY');
  $authDomain = env('FIREBASE_AUTH_DOMAIN');
  $projectId = env('FIREBASE_PROJECT_ID');
  $storageBucket = env('FIREBASE_STORE_BUCKET');
  $messagingSenderId = env('FIREBASE_MESSAGING_SENDER_ID');
  $appId = env('FIREBASE_APP_ID');
  $measurementId = env('FIREBASE_MESSAGING_ID');
?>

<!DOCTYPE html>
<html lang="es" >
  <head>
    <meta charset="UTF-8">
    <title>Admin - Exphadis</title>
    <!-- Boxiocns CDN Link -->
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="/css/style_admin.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" type="image/ico" href="https://firebasestorage.googleapis.com/v0/b/exphadisprueba2022.appspot.com/o/292109841_401005132047260_5062265451483405999_n%20(2).ico?alt=media&token=16f7b3e2-7740-4653-a37e-56682811d75c" />
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script type="module">
      import { initializeApp } from 'https://www.gstatic.com/firebasejs/9.6.11/firebase-app.js'
      import { getStorage, ref,listAll,getDownloadURL, uploadBytes } from 'https://www.gstatic.com/firebasejs/9.6.11/firebase-storage.js'
      var config = {
        apiKey: "<?= $apiKey?>",
        authDomain: "<?= $authDomain?>",
        projectId: "<?= $projectId?>",
        storageBucket: "<?= $storageBucket?>",
        messagingSenderId: "<?= $messagingSenderId?>",
        appId: "<?= $appId?>",
        measurementId: "<?= $measurementId?>"
      };

      const app = initializeApp(config);

      window.MyFirebase       = {
        db: getStorage(app),
        ref: ref,
        listAll:listAll,
        getDownloadURL:getDownloadURL,
        uploadBytes: uploadBytes

      };

  </script>
   </head>
<body>
  <!---->
  <div class="sidebar close">
    <div class="logo-details">
      <i class="fas fa-graduation-cap"></i>
      <span class="logo_name">Exphadis</span>
    </div>
    <ul class="nav-links">
      <li>
        <a href="/admin">
          <i class='bx bx-grid-alt' ></i>
          <span class="link_name">Panel Exphadis</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="/admin">Panel Exphadis</a></li>
        </ul>
      </li>
      <li>
        <div class="iocn-link">
          <a>
            <i class='bx bx-window-alt' ></i>
            <span class="link_name">Web Principal</span>
          </a>
          <i class='bx bxs-chevron-down arrow' ></i>
        </div>
        <ul class="sub-menu">
          <li><a class="link_name">Web Principal</a></li>
          <li><a href="/horariowp">Horario</a></li>
          <li><a href="/menuwp">Menu</a></li>
          <li><a href="/bannerwp">Banner</a></li>
          <li><a href="/nosotroswp">Nosotros</a></li>
          <li><a href="/pilareswp">Pilares</a></li>
          <li><a href="/propuestawp">Propuesta</a></li>
          <li><a href="/galeria">Galeria</a></li>
          <li><a href="/googlemaps">Google Maps</a></li>
          <li><a href="/anuncioswp">Anuncios</a></li>
        </ul>
      </li>
      <li>
        <div class="iocn-link">
          <a>
            <i class='bx bx-window' ></i>
            <span class="link_name">Web Matricula</span>
          </a>
          <i class='bx bxs-chevron-down arrow' ></i>
        </div>
        <ul class="sub-menu">
          <li><a class="link_name">Web Matricula</a></li>
          <li><a href="/menuwm">Menu</a></li>
          <li><a href="/bannerwm">Banner</a></li>
          <li><a href="/matriculawm">Matricula</a></li>
          <li><a href="/formulariowm">Formulario</a></li>
        </ul>
      </li>
      <li>
        <div class="iocn-link">
          <a>
            <i class='bx bx-cog' ></i>
            <span class="link_name">Config</span>
          </a>
          <i class='bx bxs-chevron-down arrow' ></i>
        </div>
        <ul class="sub-menu">
          <li><a class="link_name">Configuracion</a></li>
          <li><a href="/profile">Perfil Admin</a></li>
          <li><a href="/contacto">Contacto</a></li>
          <li><a href="/redes">Redes Sociales</a></li>
        </ul>
      </li>

      <li>
        <div class="iocn-link">
          <a href="/galeriafotos">
            <i class='bx bx-photo-album'></i>
            <span class="link_name">Galeria Fotos</span>
          </a>
        </div>
      </li>
      <li>
    <div class="profile-details">
      <div class="profile-content">
        <img src="https://firebasestorage.googleapis.com/v0/b/exphadisprueba2022.appspot.com/o/292109841_401005132047260_5062265451483405999_n.jpg?alt=media&token=17553484-3623-4a1f-9bee-6933b9851257" alt="">
      </div>
      <div class="name-job">
        <div class="profile_name">Exphadis</div>
        <div class="job">Admin</div>
      </div>
      <a href="/logout"><i class='bx bx-log-out' ></i></a>
    </div>
  </li>
</ul>
  </div>
  <section class="home-section">
    <div class="home-content">
      <i class='bx bx-menu' ></i>
      <span class="text">Panel</span>
    </div>

    <div class="limiter">
<!--<div class="container-table100">-->
    <div class="container">
        <div class="row">
            <div class="col-md-12">
              <?php echo $__env->yieldContent('content'); ?>

            </div>
        </div>
    </div>
<!--</div>-->
</div>
</section>

<section class="modal ">
  <i class="modal__close fa fa-window-close"></i>
  <div class="modal__container">
    <div class="contenedor-modal" id="container">
        <h1>Cargar Imagenes</h1>
        <form action="">
          
          <br>
          <div class="container">
            <div class="row">
                      <div class="mostrar-imagen-exphadis modal_cargar_imagenes bc-default">
              </div>
              <br>
              <br>
            </div>
          </div>
        </form>
    </div>
  </div>
</section>

<section class="modal_subir">
  <div class="modal__container_subir">
      <h2 class="modal__title_subir">Subir Imagenes</h2>
      <form onsubmit="return false" class="form-modal">
      <span></span>
        <input type="file" id="imagenExphadis" name="imagenExphadis" accept=".jpg,.png"/>
      <div class="images-subir">
        <div class="image-box" data-name="">
          <div class="pruebadoraaaaa"></div>
        </div>
      </div>
      <button class="button-modals subirr">Subir</button>
      </form>
        <i class="modal__close_subir fa fa-window-close"></i>
  </div>
</section>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script type="text/javascript">
      let arrow = document.querySelectorAll(".arrow");
      for (var i = 0; i < arrow.length; i++) {
        arrow[i].addEventListener("click", (e)=>{
      let arrowParent = e.target.parentElement.parentElement;//selecting main parent of arrow
      arrowParent.classList.toggle("showMenu");
        });
      }

      let sidebar = document.querySelector(".sidebar");
      let sidebarBtn = document.querySelector(".bx-menu");
      console.log(sidebarBtn);
      sidebarBtn.addEventListener("click", ()=>{
        sidebar.classList.toggle("close");
      });
</script>

<script type="text/javascript">

const openModal_subir = document.querySelectorAll('.hero__cta_subir');
  const modal_subir = document.querySelector('.modal_subir');
  const closeModal_subir = document.querySelectorAll('.modal__close_subir');
  let disparador_subir = null;

        window.loadmodales = () => {
          const openModal_subir = document.querySelectorAll('.hero__cta_subir');
          Object.values(openModal_subir).map(el =>
            el.addEventListener('click', (e)=>{
                e.preventDefault();
                window.currentRowEditImg = Number(e.target.dataset.id);
                modal_subir.classList.add('modal--show_subir');
                window.disparador_subir = e.target;

            })
  );
        }

  Object.values(openModal_subir).map(el =>
    el.addEventListener('click', (e)=>{
        e.preventDefault();
        window.currentRowEditImg = Number(e.target.dataset.id);
        modal_subir.classList.add('modal--show_subir');
        window.disparador_subir = e.target;

    })
  );

  Object.values(closeModal_subir).map(el=>
      el.addEventListener('click', (e)=>{
          e.preventDefault();
          modal_subir.classList.remove('modal--show_subir');

    })
  );
  //VENTANA EMERGENTE busca la galeria su js
  const openModal = document.querySelectorAll('.hero__cta');
  const modal = document.querySelector('.modal');
  const closeModal = document.querySelectorAll('.modal__close');
    let disparador = null;

        window.loadmodales = () => {
          const openModal = document.querySelectorAll('.hero__cta');
          Object.values(openModal).map(el =>
            el.addEventListener('click', (e)=>{
                e.preventDefault();
                window.currentRowEditImg = Number(e.target.dataset.id);
                modal.classList.add('modal--show');
                window.disparador = e.target;

            })
  );
        }

  Object.values(openModal).map(el =>
    el.addEventListener('click', (e)=>{
        e.preventDefault();
        window.currentRowEditImg = Number(e.target.dataset.id);
        modal.classList.add('modal--show');
        window.disparador = e.target;

    })
  );

  Object.values(closeModal).map(el=>
      el.addEventListener('click', (e)=>{
          e.preventDefault();
          modal.classList.remove('modal--show');

    })
  );

  const firebase = window.MyFirebase;

  /*================= ESTILOS EFECTO ===        ==================*/
  // const signUpButton = documen t.getElementById('signUp');
  //   const signInButton = document.getElementById('signIn');
  //   const container = document.g      etElementById('container');

  //   signUpButton.addEventListener('click', () => {
  //     container.classList.add("right-panel-active");
  //   });

  //   signInButton.addEventListener('click', () => {
  //     container.classList.remove("right-panel-active");
  //   });

  window.onload = inicializar;

  async function inicializar(){
    // let imagenesRef = window.MyFirebase.ref(window.MyFirebase.db,'imagenes');
    fetch('/ajax/loadimg?bajar=true').then(async (res) => {
      res = await res.json();
      res.items.map(el=>{
        document.querySelector('div.mostrar-imagen-exphadis').innerHTML += `<img style="padding:4px;" class="img_galery_admin seleccionimgcargadora cursor-pointer" src="${el.url_media}"/>`;
      });
      if(document.querySelector('.mostrar-imagen-exphadis2')!=null){

        res.items.map(el=>{
          document.querySelector('.mostrar-imagen-exphadis2').innerHTML += `<img style="padding:4px;" class="img_galery_admin img_gallery_fotos_general${el.id}" src="${el.url_media}"><span onclick="eliminarFotitoChida(event)" data-id="${el.id}" class="delete_img">X</span></img>`;
                });
      }

      Object.values(document.querySelectorAll('.seleccionimgcargadora')).map(el=>{
        el.addEventListener('click',()=>{
          window.disparador.src = el.src;
          if(window.disparador.dataset.galery){
            window.galupdate();
            return;
          }
          document.querySelector('input#'+window.disparador.dataset.name).value = el.src;
        })
      })
    })
  }

  function mostrarImagenDeFireBase(){
    let data = datosImagenExphadis.listAll();
    console.log(data)
    imagenExphadisRef.on("value", function(snapshot){
      var datosImagenExphadis = snapshot.val();
      var resultImagenExphadis = "";
      for(var key in datosImagenExphadis){
        resultImagenExphadis += '<img src="' + datosImagenExphadis[key].url + '"/>';
      }
    })
  }
  var fichero = document.getElementById('imagenExphadis');

  const btnSubirFB  = document.querySelector('button.subirr');

  fichero.addEventListener('change',()=>{

     var file = fichero.files[0];
    getBase64(file).then(res=>{
      document.querySelector('.pruebadoraaaaa').innerHTML = `<img class="img_small img-fluid rounded-top" src="${res}"/>`;
    }).catch(console.log);
  })

  function getBase64(file) {
    return new Promise((resolve,reject)=>{
      var reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = function () {
        resolve(reader.result);
      };
      reader.onerror = function (error) {
        reject('Error: ', error);
      };
    });
  }
  var esperando = false;

  btnSubirFB.addEventListener('click',()=>{

      var imgSubir = fichero.files[0];

      if(imgSubir && !esperando){
        let $local = '<?php echo e($APP_ENV); ?>';
        let isProduction = $local === 'local' ? false : true;
        let basePath = isProduction ? 'production' : 'development';
        esperando = true;

        const imagePath = `web/${basePath}/imagenes/galeries/${imgSubir.name}`;

        window.MyFirebase.uploadBytes(window.MyFirebase.ref(window.MyFirebase.db, imagePath), imgSubir).then(async (snapshot) => {
          let url= await window.MyFirebase.getDownloadURL( window.MyFirebase.ref(window.MyFirebase.db, imagePath));
          let ok = await fetch('/ajax/loadimg?url='+encodeURIComponent(url));
          ok = await ok.json();
          // if(window.disparador.dataset.banner){
          //   window.disparador.src = ok.url;
          //   document.query         Selector('input#'+window.disparador.dataset.name).value = ok.url;
          // }
          // if(window.disparador.dataset.galery){
          //   window.disparador.src = ok.url;
          //   window.galupdate();
          // }
          document.querySelector('div.mostrar-imagen-exphadis').innerHTML += `<img src="${ok.url}"/>`;
          document.querySelector('.pruebadoraaaaa').innerHTML = `<img class="seleccionimgcargadora" src="${ok.url}"/>`;
          // ya subio la imagen y el link de la iamgen es este: ok.url
          try {
            document.querySelector('.imgdata-'+window.currentRowEditImg).src = ok.url;
          }
          catch (error) {

          }

          window.location.reload();

          esperando = false;

          // window.disparador.src = ok.url;
          // document.querySelector('input#'+window.disparador.dataset.name).value = ok.url;

          // Object.values(document.querySelectorAll('.seleccionimgcargadora')).map(el=>{
          //   el.addEventListener('click',()=>{
          //     window.disparador.sr            c = el.src;
          //     document.querySelector('input#'+window.disparador.dat          aset.name).value = el.src;
          //   })
          // })

        });
      }
  });


</script>

</body>
</html>
<?php /**PATH C:\Users\Leo\Desktop\exphadiss\resources\views/base.blade.php ENDPATH**/ ?>