
<?php $__env->startSection('content'); ?>
                    <div class="card">
                        <form method="post">
                            <div class="card-body p-1">
                                <h4 class="text-inherit">Nosotros Web Principal</h4>
                                <?php echo csrf_field(); ?>
                                <button class="button_editar button-right" type="submit">Guardar</button>
                                <hr class="mt-2 mb-2">
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="col-lg-6 mb-4">
                                            <div class="card h-100 p-1 shadow">
                                                <div class="form-group">
                                                    <h4 class="text-inherit">Titulo</h4>
                                                    <input type="text" <?php if($data && $data->title_seccion): ?> value="<?php echo e($data->title_seccion); ?>" <?php endif; ?>  class="form-control" id="titulo" name="titulo" placeholder="">
                                                </div>
                                                <hr>
                                                <div class="form-group mt-1">
                                                    <h4 class="text-inherit">Sub Titulo 1</h4>
                                                    <input  <?php if($data && $data->sub_title): ?> value="<?php echo e($data->sub_title); ?>" <?php endif; ?> type="text" class="form-control" id="sub_titulo_1" name="sub_titulo_1" placeholder="">
                                                </div>
                                                <hr>
                                                <div class="form-group mt-1">
                                                    <h4 class="text-inherit">Sub Titulo 2</h4>
                                                    <input  <?php if($data && $data->sub_title_2): ?> value="<?php echo e($data->sub_title_2); ?>" <?php endif; ?> type="text" class="form-control" id="sub_titulo_2" name="sub_titulo_2" placeholder="">
                                                    <br>
                                                </div>
                                                <hr>
                                                <div class="form-group mt-1">
                                                    <h4 class="text-inherit">Contenido</h4>
                                                    <textarea class="form-control" id="contenido" name="contenido" rows="8"><?php if($data && $data->description): ?><?php echo e($data->description); ?><?php endif; ?></textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 mb-4">
                                            <div class="card h-100 p-1 shadow">
                                                    <h4 class="text-inherit">Imagen</h4></br>
                                                    <img data-name="imagennosotros" src="<?php if($data): ?><?php echo e($data->content_optional); ?><?php endif; ?>" class="bc-content-img2 cursor-pointer hero__cta img-fluid-2 rounded-top" name="imagennosotros">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <input type="hidden" id="imagennosotros" value="<?php if($data): ?><?php echo e($data->content_optional); ?><?php endif; ?>" name="imagennosotros">
                        </form>
                    </div>
                    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Leo\Desktop\exphadiss\resources\views/nosotroswp.blade.php ENDPATH**/ ?>