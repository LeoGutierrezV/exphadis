
<?php $__env->startSection('content'); ?>
<form method="post">
                    <div class="card container-fluid">
                        <div class="card-body p-1">
                            <h4 for="menu" class="text-inherit">Formulario</h4>
                                     <?php echo csrf_field(); ?>
                                    <button class="button_editar button-right" type="submit">Guardar</button>
                            <hr class="mt-2 mb-2">
                                <div class="container-fluid">
                                    <div class="row">
                                    
                                        <div class="col-lg-6 mb-4">
                                            <div class="card h-100 p-2 shadow">
                                                <h4 class="text-inherit">Titulo</h4>
                                                <hr>
                                                <input type="text" <?php if($data && $data->title_seccion): ?> value="<?php echo e($data->title_seccion); ?>" <?php endif; ?> name="tituloform" class="form-control">
                                                <hr>
                                                <h4 class="text-inherit">Sub Titulo</h4>
                                                <input type="text" <?php if($data && $data->sub_title): ?> value="<?php echo e($data->sub_title); ?>" <?php endif; ?> name="sub_tituloform" class="form-control">
                                                <hr>
                                            </div>
                                        </div>


                                        <div class="col-lg-6 mb-4">
                                            <div class="card h-100 p-2 shadow">
                                            <h4 class="text-inherit">Correo Colegio Exphadis</h4>
                                            <hr>
                                            <input type="text" <?php if($data && $data->content_optional): ?> value="<?php echo e($data->content_optional); ?>" <?php endif; ?> name="correo" class="form-control">
                                            <hr>
                                            </div>
                                        </div>
                                        
                                    </div>
                                </div>
                            
                        </div>
                    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Leo\Desktop\exphadiss\resources\views/formulariowm.blade.php ENDPATH**/ ?>