
<?php $__env->startSection('content'); ?>
<form method="post">
    <div class=""style="position: absolute;right:3rem;display;flex;top:-1.2rem">
        <div class="mt-2">
            <div class="swtich-container">
            <i class="bx bx-window-alt" style="top:-0.6rem !important;right:9px;position:relative;color:#fff;font-size:20px;"></i>
                <input type="checkbox" id="switch">
                <label for="switch" class="lbl"></label>
            <i class="bx bx-window" style="margin-left: 10px;top:2.35rem !important;position:absolute;color:#fff;font-size:20px;"></i>
            </div>
        </div>
    </div>
<div class="card">                    
    <div class="container">
        <div class="row">
            <!--<div class="col-xl-4 col-lg-6 mb-2">
                <div class="card mb-4 h-100 card-hover shadow">
                    <div class="container-fluid p-2">
                        <div class="row">

                            <div class="">
                                <p>Web Principal</p>
                            </div>
                            
                            aqui va el boton

                            <div class="">
                                <p>Web Matricula</p>
                            </div>

                        </div>
                    </div>
                </div>
            </div>-->
            <!--<div class="col-xl-4 col-lg-6 mb-2">
                <div class="card mb-4 h-100 card-hover shadow">
                    <div class="d-flex justify-content-between align-items-center p-4">
                        Escritorios <h3> 1</h3>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-lg-6 mb-2">
                <div class="card mb-4 h-100 card-hover shadow">
                    <div class="d-flex justify-content-between align-items-center p-4">
                        <p>Contenidos Publicados <h3> 25</h3></p>
                        <p>Contenidos Ocultos <h3> 25</h3></p>
                    </div>
                </div>
            </div>-->
        
            <div class="col-xl-4 col-lg-6 mt-2">
                <table class="table" style="border:15px">
                    <thead class="thead-dark">
                        <tr>
                            <th scope="col">Seccion</th>
                            <th scope="col">Visibilidad</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="text-center">
                                Horario
                            </td>
                            <td>
                                    <div class="switch">
                                        <input type="checkbox" <?php if($data): ?> <?php if($data->horario->visible): ?> checked <?php endif; ?> <?php endif; ?>  name="horariocheck"/>
                                        <div></div>
                                    </div>
                            </td>
                        </tr>
                        <tr>
                            <td class="text-center">
                                Menu
                            </td>
                            <td>
                                    <div class="switch">
                                        <input type="checkbox" <?php if($data): ?> <?php if($data->menu->visible): ?> checked <?php endif; ?> <?php endif; ?>  name="menucheck" />
                                        <div></div>
                                    </div>
                            </td>
                        </tr>
                        <tr>
                            <td class="text-center">
                                Banner
                            </td>
                            <td>
                                    <div class="switch">
                                        <input type="checkbox" <?php if($data): ?> <?php if($data->banner->visible): ?> checked <?php endif; ?> <?php endif; ?>  name="bannercheck" />
                                        <div></div>
                                    </div>
                            </td>
                        </tr>
                        <tr>
                            <td class="text-center">
                                Nosotros
                            </td>
                            <td>
                                    <div class="switch">
                                        <input type="checkbox" <?php if($data): ?> <?php if($data->nosotros->visible): ?> checked <?php endif; ?> <?php endif; ?>  name="nosotroscheck" />
                                        <div></div>
                                    </div>
                            </td>
                        </tr>
                        <tr>
                            <td class="text-center">
                                Pilares
                            </td>
                            <td>
                                    <div class="switch">
                                        <input type="checkbox" <?php if($data): ?> <?php if($data->pilares->visible): ?> checked <?php endif; ?> <?php endif; ?>  name="pilarescheck" />
                                        <div></div>
                                    </div>
                            </td>
                        </tr>
                        <tr>
                            <td class="text-center">
                                Propuestas
                            </td>
                            <td>
                                    <div class="switch">
                                        <input type="checkbox" <?php if($data): ?> <?php if($data->propuesta->visible): ?> checked <?php endif; ?> <?php endif; ?>  name="propuestacheck" />
                                        <div></div>
                                    </div>
                            </td>
                        </tr>
                        <tr>
                            <td class="text-center">
                                Galeria
                            </td>
                            <td>
                                    <div class="switch">
                                        <input type="checkbox" <?php if($data): ?> <?php if($data->galeria->visible): ?> checked <?php endif; ?> <?php endif; ?>  name="galeriacheck" />
                                        <div></div>
                                    </div>
                            </td>
                        </tr>
                        <tr>
                            <td class="text-center">
                                Anuncios
                            </td>
                            <td>
                                    <div class="switch">
                                        <input type="checkbox" <?php if($data): ?> <?php if($data->anuncios->visible): ?> checked <?php endif; ?> <?php endif; ?>  name="anuncioscheck" />
                                        <div></div>
                                    </div>
                            </td>
                        </tr>
                        <tr>
                            <td class="text-center">
                                Google Maps
                            </td>
                            <td>
                                    <div class="switch">
                                        <input type="checkbox" <?php if($data): ?> <?php if($data->googlemaps->visible): ?> checked <?php endif; ?> <?php endif; ?>  name="googlemapscheck" />
                                        <div></div>
                                    </div>
                            </td>
                        </tr>
                        <tr>
                            <td class="text-center">
                                Contactos
                            </td>
                            <td>
                                    <div class="switch">
                                        <input type="checkbox" <?php if($data): ?> <?php if($data->contacto->visible): ?> checked <?php endif; ?> <?php endif; ?>  name="contactocheck" />
                                        <div></div>
                                    </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="col-xl-4 col-lg-6 mt-2">
                <table class="table" style="border:15px">
                    <thead class="thead-dark">
                        <tr>
                            <th scope="col">Seccion</th>
                            <th scope="col">Visibilidad</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr> 
                            <td class="text-center">
                                Menu
                            </td>
                            <td>
                                    <div class="switch">
                                        <input type="checkbox" <?php if($data): ?> <?php if($data->menumatricula->visible): ?> checked <?php endif; ?> <?php endif; ?>  name="menumatriculacheck" />
                                        <div></div>
                                    </div>
                            </td>
                        </tr>
                        <tr>
                            <td class="text-center">
                                Banner
                            </td>
                            <td>
                                    <div class="switch">
                                        <input type="checkbox" <?php if($data): ?> <?php if($data->bannermatricula->visible): ?> checked <?php endif; ?> <?php endif; ?>  name="bannermatriculacheck" />
                                        <div></div>
                                    </div>
                            </td>
                        </tr>
                        <tr>
                            <td class="text-center">
                                Matricula
                            </td>
                            <td>
                                    <div class="switch">
                                        <input type="checkbox" <?php if($data): ?> <?php if($data->opcionesmatricula->visible): ?> checked <?php endif; ?> <?php endif; ?>  name="opcionesmatriculacheck" />
                                        <div></div>
                                    </div>
                            </td>
                        </tr>
                        <tr>
                            <td class="text-center">
                                Formulario
                            </td>
                            <td>
                                    <div class="switch">
                                        <input type="checkbox" <?php if($data): ?> <?php if($data->formulariomatricula->visible): ?> checked <?php endif; ?> <?php endif; ?>  name="formulariomatriculacheck" />
                                        <div></div>
                                    </div>
                            </td>
                        </tr>
                        <tr>
                            <td class="text-center">
                                Google Maps
                            </td>
                            <td>
                                    <div class="switch">
                                        <input type="checkbox" <?php if($data): ?> <?php if($data->googlemapsmatricula->visible): ?> checked <?php endif; ?> <?php endif; ?>  name="googlemapsmatricula" />
                                        <div></div>
                                    </div>
                            </td>
                        </tr>
                        <tr>
                            <td class="text-center">
                                Contacto
                            </td>
                            <td>
                                    <div class="switch">
                                        <input type="checkbox" <?php if($data): ?> <?php if($data->contactomatricula->visible): ?> checked <?php endif; ?> <?php endif; ?>  name="contactomatricula" />
                                        <div></div>
                                    </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
                <?php echo csrf_field(); ?>
                <button class="button_editar" type="submit">Guardar</button>
            </div>
        </div>
    </div>
</div>
</form>
<script>
    const switasd = document.querySelector('#switch');

    switasd.addEventListener('change',async ()=>{
        await fetch('/changetype?check='+switasd.checked);
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Leo\Desktop\exphadiss\resources\views/admin.blade.php ENDPATH**/ ?>