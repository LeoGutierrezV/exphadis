
<?php $__env->startSection('content'); ?>
<form method="post">
                    <div class="card container-fluid">
                        <div class="card-body p-1">
                            <h4 for="menu" class="control-label">Contacto</h4>
                                     <?php echo csrf_field(); ?>
                                    <button class="button_editar button-right" type="submit">Guardar</button>
                            <hr class="mt-2 mb-2">
                                <div class="container-fluid">
                                    <div class="row">
                                    
                                        <div class="col-xl-4 col-lg-6 mb-4">
                                            <div class="card h-100 p-2 shadow">
                                            <h4 class="text-inherit">Niveles</h4>
                                            <hr>
                                            <input type="text" value="<?php if($data): ?><?php echo e($data->niveles->nivel1); ?><?php endif; ?>" name="nivel1" class="form-control">
                                            <hr>
                                            <input type="text" value="<?php if($data): ?><?php echo e($data->niveles->nivel2); ?><?php endif; ?>" name="nivel2" class="form-control">
                                            <hr>
                                            <input type="text" value="<?php if($data): ?><?php echo e($data->niveles->nivel3); ?><?php endif; ?>" name="nivel3" class="form-control">
                                            <hr>
                                            </div>
                                        </div>
                                        <div class="col-xl-4 col-lg-6 mb-4">
                                            <div class="card h-100 p-2 shadow">
                                            <h4 class="text-inherit">Visitanos</h4>
                                            <hr>
                                            <textarea class="form-control mt-1 mb-1" id="ubicacion" name="ubicacion" rows="5"><?php if($data): ?><?php echo e($data->visitanos->ubicacion); ?><?php endif; ?></textarea>
                                            <hr>
                                            </div>
                                        </div>
                                        
                                        <div class="col-xl-4 col-lg-6 mb-4">
                                            <div class="card h-100 p-2 shadow">
                                            <h4 class="text-inherit">Telefonica</h4>
                                            <hr>
                                            <input type="text" value="<?php if($data): ?><?php echo e($data->telefonica->num1); ?><?php endif; ?>" name="num1" class="form-control">
                                            <hr>
                                            <input type="text" value="<?php if($data): ?><?php echo e($data->telefonica->num2); ?><?php endif; ?>" name="num2" class="form-control">
                                            <hr>
                                            <input type="text" value="<?php if($data): ?><?php echo e($data->telefonica->num3); ?><?php endif; ?>" name="num3" class="form-control">
                                            <hr>
                                            </div>
                                        </div>

                                        <div class="col-lg-6 mb-4">
                                            <div class="card h-100 p-2 shadow">
                                            <h4 class="text-inherit">Copyright</h4>
                                            <hr>
                                            <input type="text" value="" name="" class="form-control">
                                            <hr>
                                            </div>
                                        </div>
                                        
                                    </div>
                                </div>
                            
                        </div>
                    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Leo\Desktop\exphadiss\resources\views/contacto.blade.php ENDPATH**/ ?>