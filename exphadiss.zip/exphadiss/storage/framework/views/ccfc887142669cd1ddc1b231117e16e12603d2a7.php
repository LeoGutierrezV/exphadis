
<?php $__env->startSection('content'); ?>
<form onsubmit="return false">
    <div class="card">
        <div class="card-body p-4">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-6 col-12 mb-4">
                        <div class="card h-100 p-1 shadow">
                                <span>Solo se pueden subir imagenes tipo: jpg ,png ,svg</span>
                                <input type="file" id="imagenExphadis" name="imagenExphadis" enctype="multipart/form-data" accept=".jpg,.png"/>
                                <br>
                                <button class="button-modals subirr">Subir</button>
                        </div>
                    </div>
                    <div class="col-lg-6 col-12">
                        <div class="card p-1 shadow">

                            <div class="images-subir">
                                <div class="image-box" data-name="">
                                    <div class="pruebadoraaaaa">
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <img src="<?php echo e($url->url_media); ?>"/>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>
<script>
    if(!window.opener){
    let ventanita = window.open('http://'+window.location.host+'/subirimagen','Nuev ventanisadalskidn','height=550,width=650');
    ventanita.focus();
    window.addEventListener('message',(e)=>console.log(e));
    console.log()    
    }else{
        window.opener.postMessage("hola",
        window.opener.location.href);
    }estyo coinb ub ckeutbe
    console.log(window.opener.location.href);

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Leo\Desktop\exphadiss\resources\views/subirimagen.blade.php ENDPATH**/ ?>