<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="author" content="">
<title>Exphadis</title>
<meta name="description" content="">
<meta name="author" content="">
<!-- Stylesheet================================================== -->
<link rel="stylesheet" type="text/css"  href="css/style-general.css">
<link rel="stylesheet" type="text/css"  href="css/style.css">
<!--<link rel="stylesheet" type="text/css" href="css/prettyPhoto.css">-->
<link rel="shortcut icon" type="ico/icon" href="https://firebasestorage.googleapis.com/v0/b/exphadisprueba2022.appspot.com/o/292109841_401005132047260_5062265451483405999_n%20(2).ico?alt=media&token=16f7b3e2-7740-4653-a37e-56682811d75c">
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
<link href='http://fonts.googleapis.com/css?family=Lato:400,700,900,300' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800,600,300' rel='stylesheet' type='text/css'>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

</head>
<body>
  <!--PANTALLA DE CARGA-->
  <div class="preloader">
		<div class="loader-container">
				<img loading="lazy" src="https://firebasestorage.googleapis.com/v0/b/exphadisprueba2022.appspot.com/o/292109841_401005132047260_5062265451483405999_n.jpg?alt=media&token=17553484-3623-4a1f-9bee-6933b9851257" class="shadow">
    </div>
	</div>
  <!--FIN DE PANTALLA DE CARGA-->
<?php if($adminmatricula->menumatricula->visible): ?>
  <nav id="menu" class="navbar-2 navbar-default-2 navbar-fixed-top-2 on-2">
    <div class="container"> 
      <div class="navbar-header transparent">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"> <span class="sr-only"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
        <a href="/"><span class="img_menu_wm"><img class="img-header-exphadis" src="<?php if($menu): ?><?php echo e($menu->admision->img); ?> <?php endif; ?>"></span></a>
      </div>
      <div class="collapse navbar-collapse text-center" id="bs-example-navbar-collapse-1">
        <ul class="nav navbar-nav navbar-right">
          <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($link->visible==true): ?>
              <li><a href="<?php echo e($link->url); ?>" class="page-scroll active"><?php echo e($link->nombre); ?></a></li>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
    </div>
  </nav>
<?php endif; ?>
<?php if($adminmatricula->bannermatricula->visible): ?>
<section id="#" class="home-matricula">
<header class="masthead text-center text-white">
    <div class="masthead-content">
    <div class="container align-items-center">
      <div class="row_banner align-items-center">
           
            <div class="col-md-6 text-md-start text-center"><!--py-6-->
                <h1 class="text-white"><?php if($bannerwm_title): ?><?php echo e($bannerwm_title); ?> <?php endif; ?></h1>
                <h1 class="mb-4 fw-bold text-white"> <?php if($bannerwm_subtitle): ?><?php echo e($bannerwm_subtitle); ?> <?php endif; ?></h1>
                <p class="mb-4 text-white text_banner_content fs-p">
                <?php if($bannerwm_cont): ?><?php echo e($bannerwm_cont); ?> <?php endif; ?>
                </p>
                <p class="mb-4 text-white text_banner_content fs-p">¿Quieres conocer más?</p>
                <div class="text-center text-md-start">
                <?php if($bannerwm_options->boton->visible): ?>
                 <a href="<?php if($bannerwm_options): ?><?php echo e($bannerwm_options->boton->link); ?> <?php endif; ?>" class="button-banner-1"><i class="fa fa-plus-circle"></i> <?php if($bannerwm_options): ?><?php echo e($bannerwm_options->boton->nombre); ?> <?php endif; ?></a>
                <?php endif; ?>
                 <a href="#contact-section" class="page-scroll button-banner-2">Regístrate Aquí</a>
                </div>
            </div>

            <div class="col-md-6 text-end m-a mt-3">
              <div class="">
                <span class="">
                <img loading="lazy" src="<?php if($bannerwm_options): ?><?php echo e($bannerwm_options->img_bannerwm->img); ?> <?php endif; ?>" class="pt-md-0 img-fluid">
                </span>
              </div>
            </div>
      </div>
    </div>
    </div>
    <div class="bg-circle-1 bg-circle"></div>
    <div class="bg-circle-2 bg-circle"></div>
    <div class="bg-circle-3 bg-circle"></div>
    <div class="bg-circle-4 bg-circle"></div>
</header>
</section>
<?php endif; ?>
<!--============PROCESO MATRICULA============-->
<!-- About Section -->
<?php if($adminmatricula->opcionesmatricula->visible): ?>
<div id="services-section" class="services-section-2">
  <div class="container-fluid-2">
    <div class="section-title">
      <h1 class="fw-8 color-text-exphadis text-center"><?php if($titulomw): ?><?php echo e($titulomw); ?> <?php endif; ?></h1>
        <h3 class="text-center"><?php if($sub_titulomw): ?><?php echo e($sub_titulomw); ?> <?php endif; ?></h3>
      <hr>
    </div>
    <div class="row-2">
      <?php $__currentLoopData = $matriculawmcont; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $matriculawm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <div class="rs_order_2 rs_order_3 p-1">
        <div class="card2 h-100 p-1 shadow_2 hero__cta" data-class="<?php echo e($key); ?>">
          <div class="card-body2" data-class="<?php echo e($key); ?>">
          <img loading="lazy" src="<?php echo e($matriculawm->img); ?>" class="img-responsive-3" alt="colegioexphadis" data-class="<?php echo e($key); ?>">
          <h5 class="fw-8 text-center" data-class="<?php echo e($key); ?>"><?php echo e($matriculawm->titulo); ?></h5>
          <p class="responsive-text-p fw-bold text-center" data-class="<?php echo e($key); ?>"><?php echo e($matriculawm->contenido); ?></p>
          </div>
          
        </div>
      </div>
   
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
  </div>
</div>
<?php endif; ?>
<!--=========CONTACT-SECTION===========-->
<?php if($adminmatricula->formulariomatricula->visible): ?>
<div id="contact-section" class="background-white">
  <div class="container">

    <div class="wrapper" style="box-shadow: 10px 10px 50px rgba(0, 0, 0, 0.5);">
      <h3 class="text-center"><?php if($formulariowm): ?><?php echo e($formulariowm->title_seccion); ?> <?php endif; ?></h3>
      <h4 class="text-center"><?php if($formulariowm): ?><?php echo e($formulariowm->sub_title); ?> <?php endif; ?></h4>

      <form method="POST" class="formulario" id="form">
      <?php echo csrf_field(); ?>
        <!-- Grupo: Nombre -->
        <div class="formulario__grupo" id="grupo__nombre">
          <div class="formulario__grupo-input">
            <input type="text" class="formulario__input" name="nombre" value="<?php echo e(old('nombre')); ?>" id="nombre" placeholder="John Doe">
            <span class='icons_form fas fa-user'></span>
            <i class="formulario__validacion-estado fas fa-times-circle"></i>
          </div>
          <p class="formulario__input-error">El nombre tiene que ser de 4 a 16 dígitos y solo puede contener letras.</p>
        </div>

        <!-- Grupo: apellido -->
        <div class="formulario__grupo" id="grupo__apellido">
          <div class="formulario__grupo-input">
            <input type="text" class="formulario__input" name="apellido" value="<?php echo e(old('apellido')); ?>" id="apellido" placeholder="John Doe">
            <span class='icons_form fas fa-user'></span>
            <i class="formulario__validacion-estado fas fa-times-circle"></i>
          </div>
          <p class="formulario__input-error">El apellido tiene que ser de 4 a 16 dígitos y solo puede contener letras.</p>
        </div>

        <!-- Grupo: Correo Electronico -->
        <div class="formulario__grupo" id="grupo__correo">
          <div class="formulario__grupo-input">
            <input type="email" class="formulario__input" name="correo" value="<?php echo e(old('correo')); ?>" id="correo" placeholder="correo@correo.com">
            <span class='icons_form fas fa-envelope'></span>
            <i class="formulario__validacion-estado fas fa-times-circle"></i>
          </div>
          <p class="formulario__input-error">El correo solo puede contener letras, numeros, puntos, guiones y guion bajo.</p>
        </div>

        <!-- Grupo: Dni -->
        <div class="formulario__grupo" id="grupo__dni">
          <div class="formulario__grupo-input">
            <input type="text" class="formulario__input" name="dni" value="<?php echo e(old('dni')); ?>" id="dni" placeholder="7658456">
            <span class='icons_form fas fa-id-card'></span>
            <i class="formulario__validacion-estado fas fa-times-circle"></i>
          </div>
          <p class="formulario__input-error">El DNI solo puede contener numeros y el maximo son 8 dígitos.</p>
        </div>

        <!-- Grupo: Teléfono -->
        <div class="formulario__grupo" id="grupo__telefono">
          <div class="formulario__grupo-input">
            <input type="text" class="formulario__input" name="telefono" value="<?php echo e(old('telefono')); ?>" id="telefono" placeholder="4491234567">
            <span class='icons_form fas fa-phone-alt'></span>
            <i class="formulario__validacion-estado fas fa-times-circle"></i>
          </div>
          <p class="formulario__input-error">El telefono solo puede contener numeros y el maximo son 9 dígitos.</p>
        </div>

        <!-- Grupo: Terminos y Condiciones -->
        <div class="formulario__grupo" id="grupo__terminos">
          <label class="formulario__label">
            <input class="formulario__checkbox" type="checkbox" name="terminos" id="terminos">
            Acepto los Terminos y Condiciones
          </label>
        </div>

        <div class="formulario__mensaje" id="formulario__mensaje">
          <p><i class="fas fa-exclamation-triangle"></i> <b>Error:</b> Por favor rellena el formulario correctamente. </p>
        </div>

        <div class="formulario__grupo formulario__grupo-btn-enviar">
          <input type="submit" class="formulario__btn" id="button" value="Enviar Correo" >
          <p class="formulario__mensaje-exito" id="formulario__mensaje-exito">Formulario enviado exitosamente!</p>
        </div>

        <input type="hidden" name="_captcha" value="false">
        <input type="hidden" name="_autoresponse" value="your custom message">
      </form>
      <script type="text/javascript"
      src="https://cdn.jsdelivr.net/npm/@emailjs/browser@3/dist/email.min.js"></script>

    <script type="text/javascript">
      emailjs.init('87OqsIdxhuYkfj76X')
    </script>
    </div>

  </div>
</div>
<?php endif; ?>
<?php $__currentLoopData = $matriculawmcont; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$matriculawm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<section class="modal modalss<?php echo e($key); ?>">
  <div class="modal__container">
      <h2 class="modal__title"><?php echo e($matriculawm->titulo); ?></h2>
        <div class="et_pb_text_inner">
        <?php if($matriculawm->col1->titulo): ?><p><i class="icon1 fas fa-address-card"></i><strong><?php echo e($matriculawm->col1->titulo); ?></strong></p><?php endif; ?>
          <?php $__currentLoopData = $matriculawm->col1->contenido; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <p><i class="icon far fa-check-circle"></i><?php echo e($f); ?></p>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="et_pb_text_inner">
          
        <?php if($matriculawm->col2->titulo): ?><p><i class="icon1 fas fa-user-graduate"></i><strong><?php echo e($matriculawm->col2->titulo); ?></strong></p><?php endif; ?>

          <?php $__currentLoopData = $matriculawm->col2->contenido; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <p><i class="icon far fa-check-circle"></i> <?php echo e($f1); ?></p>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <i class="modal__close fa fa-window-close"></i>
  </div>
</section>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!--================Contact Section================ -->

<div class="w-100 p-0 text-center background-white">
<?php if($adminmatricula->googlemapsmatricula->visible): ?>
  <iframe src="<?php if($googlemaps): ?><?php echo e($googlemaps->content_optional); ?> <?php endif; ?>" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
<?php endif; ?>
<?php if($adminmatricula->contactomatricula->visible): ?>
<footer>
    <div class="row-footer">
    <div class="col-footer">
        <h3>Niveles:<div class="underline"><span></span></div></h3>
        <?php if($contacto): ?>
        <?php if($key!='contacto'): ?>
        <p><?php echo e($contacto->niveles->nivel1); ?></p>
        <p><?php echo e($contacto->niveles->nivel2); ?></p>
        <p><?php echo e($contacto->niveles->nivel3); ?></p>
        <?php endif; ?>
        <?php endif; ?>
      </div>
      <div class="col-footer">
        <h3>Visítanos:<div class="underline"><span></span></div></h3>
        <?php if($contacto): ?>
        <?php if($key!='contacto'): ?>
        <p><i class="fas fa-map-marker-alt"></i><?php echo e($contacto->visitanos->ubicacion); ?></p>
        <?php endif; ?>
        <?php endif; ?>
        
      </div>
      <div class="col-footer">
        <h3>Telefónica:<div class="underline"><span></span></div></h3>
        <?php if($contacto): ?>
        <?php if($key!='contacto'): ?>
        <p><i class="fas fa-phone-alt"></i><?php echo e($contacto->telefonica->num1); ?></p>
        <p><i class="fas fa-phone-alt"></i><?php echo e($contacto->telefonica->num2); ?></p>
        <?php endif; ?>
        <?php endif; ?>
        
        
      </div>

    </div>
</footer>

<?php if(count($redes)>0): ?>
<div id="social-icons">
  <div class="text-right">
      <ul class="social-icons">
          <div class="social-btn-container">


            <?php $__currentLoopData = $redes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $red): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($red->bool): ?>
            <span class="<?php echo e($red->clase); ?>">
                <a href="<?php echo e($red->link_redes); ?>" class="<?php echo e($red->clase1); ?>">
                  <i class="<?php echo e($red->clase2); ?>"></i>
                </a>
            </span>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </div>
      </ul>
  </div>
</div>
<?php endif; ?>

<div id="footer">
  <div class="container">
    <p class="text-center">Copyright &copy; Diseñado por colegioexphadis.pe<a href="" rel="nofollow"></a></p>
  </div>
</div>
<?php endif; ?>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="https://kit.fontawesome.com/2c36e9b7b1.js" crossorigin="anonymous"></script>
<script type="text/javascript" src="js/jquery.isotope.js"></script> 
<script type="text/javascript" src="js/main.js"></script>
<script type="text/javascript" src="js/form_valid.js"></script>
<script>
  const preloader = document.querySelector(".preloader");

  window.addEventListener("load", () =>{
    preloader.style.display= "none";
  })
</script>
<script type="text/javascript">
  
  const openModal = document.querySelectorAll('.hero__cta');
  const modal = document.querySelector('.modal');
  const closeModal = document.querySelectorAll('.modal__close');
  let disparador_subir = null;

  window.loadmodales = () => {
    const openModal = document.querySelectorAll('.hero__cta');
    Object.values(openModal).map(el =>
      el.addEventListener('click', (e)=>{

        // window.currentRowEditImg = Number(e.target.dataset.id);
        console.log(e.target.dataset)
        document.querySelector('.modalss'+e.target.dataset.class).classList.add('modal--show');
        window.lastModal = document.querySelector('.modalss'+e.target.dataset.class);
                  
      })
    );
 }

  Object.values(openModal).map(el =>
    el.addEventListener('click', (e)=>{
  
        // window.currentRowEditImg = Number(e.target.dataset.id);
        console.log(e.target.dataset)

        document.querySelector('.modalss'+e.target.dataset.class).classList.add('modal--show');
        window.lastModal = document.querySelector('.modalss'+e.target.dataset.class);
        
    })
  );

  Object.values(closeModal).map(el=> 
    el.addEventListener('click', (e)=>{
      e.preventDefault();
      window.lastModal.classList.remove('modal--show');
      
    })
  );
</script>
</body>
</html><?php /**PATH C:\Users\Leo\Desktop\exphadiss\resources\views/matricula.blade.php ENDPATH**/ ?>