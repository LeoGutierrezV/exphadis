
<?php $__env->startSection('content'); ?>
<div class="card">
                        <form method="post">
                            <div class="card-body p-1">
                                <div class="container-fluid">
                                <h4 for="menu" class="text-inherit">Banner Matricula</h4>
                                <?php echo csrf_field(); ?>
                                <button class="button_editar button-right" type="submit">Guardar</button>
                                <hr class="mt-2 mb-2">
                                    <div class="row">
                                        <div class="col-lg-6 mb-4">
                                            <div class="card h-100 p-1 shadow">
                                                <div class="form-group">
                                                    <h4 class="text-inherit">Titulo</h4>
                                                    <input type="text" <?php if($data && $data->title_seccion): ?> value="<?php echo e($data->title_seccion); ?>" <?php endif; ?> class="form-control" name="titulo_banner_wm" >
                                                </div>
                                                <hr class="mb-1">
                                                <div class="form-group">
                                                    <h4 class="text-inherit">Sub Titulo</h4>
                                                    <input type="text" <?php if($data && $data->sub_title): ?> value="<?php echo e($data->sub_title); ?>" <?php endif; ?> class="form-control" name="subtitulo_banner_wm">
                                                </div>
                                                <hr>
                                                <div class="form-group mt-1">
                                                    
                                                    <div class="content-buttons-general-text mb-1">
                                                        <h4 class="text-inherit">Contenido</h4>
                                                    </div>
                                                    <textarea class="form-control" id="contenido_wm_banner" name="contenido_wm_banner" rows="8"><?php if($data && $data->description): ?><?php echo e($data->description); ?><?php endif; ?></textarea>
                                                    
                                                </div>
                                                <hr>
                                                <div class="form-group mt-1">
                                                    <div class="content-buttons-general-text mb-1">
                                                        <h4 class="text-inherit">Boton</h4>
                                                            <div class="button-right-2">
                                                                <h4>Visible</h4>
                                                                <div class="switch">
                                                                    <input type="checkbox" <?php if($data): ?> <?php if($data->boton->visible): ?> checked <?php endif; ?> <?php endif; ?> value="bannercheck1" name="bannercheck1" />
                                                                    <div></div>
                                                                </div>
                                                            </div>
                                                    </div>
                                                    <input type="text" value="<?php if($data): ?><?php echo e($data->boton->nombre); ?><?php endif; ?>" class="form-control" name="text_btn1_banner">
                                                    Link
                                                    <input type="text" value="<?php if($data): ?><?php echo e($data->boton->link); ?><?php endif; ?>" class="form-control" name="link_btn1_banner">
                                                </div>
                                                <hr>
                                            </div>
                                        </div> 
                                        <div class="col-lg-6 mb-4">
                                            <div class="card h-100 p-1 shadow">
                                                    <h4 class="text-inherit">Imagen</h4></br>
                                                        <!--<input type="file" class="form-control" id="imagen" name="imagen" placeholder="">-->
                                                    <img data-name="banner_imagen_wm" class="hero__cta bc-content-img2 cursor-pointer img-fluid" name="banner_imagen_wm" src="<?php if($data): ?><?php echo e($data->img_bannerwm->img); ?><?php endif; ?>">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <input type="hidden" value="<?php if($data): ?><?php echo e($data->img_bannerwm->img); ?><?php endif; ?>" class="form-control" id="banner_imagen_wm" name="banner_imagen_wm">
                        </form>
                    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Leo\Desktop\exphadiss\resources\views/bannerwm.blade.php ENDPATH**/ ?>