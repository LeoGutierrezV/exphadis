
<?php $__env->startSection('content'); ?>
<form method="post">
                    <div class="card container-fluid">
                        <div class="card-body p-1">
                            <h4 for="menu" class="text-inherit">Menu Web Principal</h4>
                            <?php echo csrf_field(); ?>
                            <button class="button_editar button-right" type="submit">Guardar</button>
                            <hr class="mt-2 mb-2">
                                <div class="container-fluid">
                                    <div class="row">

                                        <div class="col-xl-4 col-lg-6 mb-4">
                                            <div class="card h-100 p-2 shadow">
                                            <h4 class="text-inherit">Logo</h4>

                                            <img data-name="imglogo" id="imglogo" name="imglogo" src="<?php if($data): ?><?php echo e($data->inicio->img); ?><?php endif; ?>" class="shadow cursor-pointer bc-img hero__cta img-fluid rounded-top">
                                            
                                            </div>
                                        </div>


                                        <div class="col-xl-4 col-lg-6 mb-4">
                                            <div class="card h-100 p-2 shadow">
                                            <div class="content-buttons-general-text mb-1">
                                                        <h4 class="text-inherit"><?php echo e($data->inicio->nombre); ?></h4>
                                                    <div class="button-right-2">
                                                        <h4>Visible </h4>
                                                        <div class="switch">
                                                        <input type="checkbox" <?php if($data->inicio->visible): ?> checked <?php endif; ?>  value="ass" name="c1" />
                                                            <div></div>
                                                        </div>
                                                    </div>
                                            </div>

                                            <input type="text" value="<?php echo e($data->inicio->nombre); ?>" class="form-control" id="menu1" name="inicio" placeholder="Inicio">
                                            <input type="hidden" value="<?php echo e($data->inicio->url); ?>" name="link1" class="form-control">

                                            </div>
                                        </div>
                                        <div class="col-xl-4 col-lg-6 mb-4">
                                            <div class="card h-100 p-2 shadow">
                                            <div class="content-buttons-general-text mb-1">
                                                        <h4 class="text-inherit"><?php echo e($data->matricula->nombre); ?></h4>
                                                    <div class="button-right-2">
                                                        <h4>Visible </h4>
                                                        <div class="switch">
                                                        <input type="checkbox" <?php if($data->matricula->visible): ?> checked <?php endif; ?> value="ass"  name="c2" />
                                                            <div></div>
                                                        </div>
                                                    </div>
                                            </div>
                                            <input type="text"  value="<?php echo e($data->matricula->nombre); ?>" class="form-control" id="menu1" name="matricula">
                                            <input type="hidden" value="<?php echo e($data->matricula->url); ?>" name="link2" class="form-control">
                                            </div>
                                        </div>
                                        
                                        <div class="col-xl-4 col-lg-6 mb-4">
                                            <div class="card h-100 p-2 shadow">

                                            <div class="content-buttons-general-text mb-1">
                                                        <h4 class="text-inherit"><?php echo e($data->nosotros->nombre); ?></h4>
                                                    <div class="button-right-2">
                                                        <h4>Visible </h4>
                                                        <div class="switch">
                                                        <input type="checkbox" <?php if($data->nosotros->visible): ?> checked <?php endif; ?> value="ass" name="c3" />
                                                            <div></div>
                                                        </div>
                                                    </div>
                                            </div>
                                            <input type="text"  value="<?php echo e($data->nosotros->nombre); ?>" class="form-control" id="menu1" name="nosotros" placeholder="Nosotros">
                                            <input type="hidden" name="link3" value="#about-section">
                                            </div>
                                        </div>

                                        <div class="col-xl-4 col-lg-6 mb-4">
                                            <div class="card h-100 p-2 shadow">
                                            <div class="content-buttons-general-text mb-1">
                                                        <h4 class="text-inherit"><?php echo e($data->propuesta->nombre); ?></h4>
                                                    <div class="button-right-2">
                                                        <h4>Visible </h4>
                                                        <div class="switch">
                                                        <input type="checkbox" <?php if($data->propuesta->visible): ?> checked <?php endif; ?> value="ass"  name="c4" />
                                                            <div></div>
                                                        </div>
                                                    </div>
                                            </div>
                                            <input type="text" value="<?php echo e($data->propuesta->nombre); ?>" class="form-control" id="menu1" name="propuesta" placeholder="Propuesta">
                                            <input type="hidden" name="link4" value="#services-section">
                                            </div>
                                        </div>

                                        <div class="col-xl-4 col-lg-6 mb-4">
                                            <div class="card h-100 p-2 shadow">
                                            <div class="content-buttons-general-text mb-1">
                                                        <h4 class="text-inherit"><?php echo e($data->contacto->nombre); ?></h4>
                                                    <div class="button-right-2">
                                                        <h4>Visible </h4>
                                                        <div class="switch">
                                                        <input type="checkbox" <?php if($data->contacto->visible): ?> checked <?php endif; ?> value="ass"  name="c5" />
                                                            <div></div>
                                                        </div>
                                                    </div>
                                            </div>
                                            <input type="text"  value="<?php echo e($data->contacto->nombre); ?>" class="form-control" id="menu1" name="contacto" placeholder="Contacto">  
                                            <input type="hidden" name="link5" value="#contact-section"  class="form-control">
                                            </div>
                                        </div>
                                        
                                        <br>
                                        
                                    </div>
                                </div>
                            
                        </div>
                    </div>
    <input type="hidden" id="imglogo" value="<?php if($data): ?><?php echo e($data->inicio->img); ?><?php endif; ?>" name="imglogo">
</form>
<script>
    const btnAgregar = document.querySelector('.agregador');
    const formList = document.querySelector('.form-list');
    const inputModal = document.querySelector('#menu1');
    const btnGuardar = document.querySelector('.btn-guardar');
    
    // btnAgregar.addEventListener('click',()=>{
    //     formList.innerHTML += `
    //     <br/><br/>
    //     <input type="text" class="form-control" id="menu1" name="contact1" placeholder="Contacto">
    //                                     <br>
    //                                     <a class="button_editar hero__cta" href="#">Editar</a> <a class="button_eliminar" href="">Eliminar</a>
    //     `;
    // });

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Leo\Desktop\exphadiss\resources\views/menuwp.blade.php ENDPATH**/ ?>