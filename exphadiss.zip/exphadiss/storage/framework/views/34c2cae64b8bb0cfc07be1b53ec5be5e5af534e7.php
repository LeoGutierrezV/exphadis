
<?php $__env->startSection('content'); ?>
<form method="post">
    <div class="card">
        <div class="card-body p-1">
            <div class="container-fluid">
                <div class="form-group">
                <?php echo csrf_field(); ?>
                    <button class="button_editar button-right" type="submit">Guardar</button>
                    <h4 class="control-label text-inherit">Google Maps</h4>
                </div>
                <hr class="mt-2 mb-2">
                <div class="row">

                    <div class="col-12 mb-4">
                        <div class="card h-100 image-box">
                            <div class="card-body">
                            <div class="mb-4 container">
                                <h4 class="mt-1 mb-1 text-inherit">Ingresa la URL de Google Maps</h4>
                                <textarea class="form-control" id="googlemaps" name="googlemaps" rows="8"><?php echo e($data->content_optional); ?></textarea>
                            </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Leo\Desktop\exphadiss\resources\views/googlemaps.blade.php ENDPATH**/ ?>