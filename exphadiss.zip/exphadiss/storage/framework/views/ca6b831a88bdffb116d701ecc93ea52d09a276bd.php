
<?php $__env->startSection('content'); ?>
<form method="post">
                    <div class="card container-fluid">
                        <div class="card-body p-1">
                            <h4 for="menu" class="text-inherit">Menu Matricula</h4>
                            <?php echo csrf_field(); ?>
                            <button class="button_editar button-right" type="submit">Guardar</button>
                            <hr class="mt-2 mb-2">
                                <div class="container-fluid">
                                    <div class="row">

                                        <div class="col-xl-4 col-lg-6 mb-4">
                                            <div class="card h-100 p-2 shadow">
                                            <h4 class="text-inherit">Logo</h4>

                                            <img data-name="imglogowm" id="imglogowm" name="imglogowm" src="<?php if($data): ?><?php echo e($data->admision->img); ?><?php endif; ?>" class="shadow cursor-pointer bc-img hero__cta img-fluid rounded-top">
                                            
                                            </div>
                                        </div>

                                        <div class="col-xl-4 col-lg-6 mb-4">
                                            <div class="card h-100 p-2 shadow">
                                            <h4 class="text-inherit"></h4>

                                                <div class="content-buttons-general-text mb-1">
                                                        <h4 class="text-inherit"><?php echo e($data->admision->nombre); ?></h4>
                                                    <div class="button-right-2">
                                                        <h4>Visible </h4>
                                                        <div class="switch">
                                                            <input type="checkbox" <?php if($data->admision->visible): ?> checked <?php endif; ?> value="ass" name="m1" />
                                                            <div></div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <input type="text" value="<?php echo e($data->admision->nombre); ?>" class="form-control" id="menu1" name="admision" placeholder="ADMISIÓN">
                                                <!--<p>Link</p>-->
                                                <input type="hidden" value="<?php echo e($data->admision->url); ?>" name="linkm1" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-xl-4 col-lg-6 mb-4">
                                            <div class="card h-100 p-2 shadow">
                                            <h4 class="text-inherit"></h4>

                                                <div class="content-buttons-general-text mb-1">
                                                        <h4 class="text-inherit"><?php echo e($data->tutoriales->nombre); ?></h4>
                                                    <div class="button-right-2">
                                                        <h4>Visible </h4>
                                                        <div class="switch">
                                                            <input type="checkbox" <?php if($data->tutoriales->visible): ?> checked <?php endif; ?> value="ass" name="m2" />
                                                            <div></div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <input type="text"  value="<?php echo e($data->tutoriales->nombre); ?>" class="form-control" id="menu1" name="tutoriales" placeholder="TUTORIALES
">
                                                <p>Link</p>
                                                <input type="text" value="<?php echo e($data->tutoriales->url); ?>" name="linkm2" class="form-control">
                                            </div>
                                        </div>
                                         
                                        <div class="col-xl-4 col-lg-6 mb-4">
                                            <div class="card h-100 p-2 shadow">
                                            <h4 class="text-inherit"></h4>

                                                <div class="content-buttons-general-text mb-1">
                                                        <h4 class="text-inherit"><?php echo e($data->contactanos->nombre); ?></h4>
                                                    <div class="button-right-2">
                                                        <h4>Visible </h4>
                                                        <div class="switch">
                                                            <input type="checkbox" <?php if($data->contactanos->visible): ?> checked <?php endif; ?> value="ass" name="m3" />
                                                            <div></div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <input type="text"  value="<?php echo e($data->contactanos->nombre); ?>" class="form-control" id="menu1" name="contactanos" placeholder="CONTACTANOS">
                                                <input type="hidden" name="linkm3" value="#contact-section" class="form-control">
                                            </div>
                                        </div>
                                        
                                    </div>
                                </div>
                            
                        </div>
                    </div>
<input type="hidden" id="imglogowm" value="<?php if($data): ?><?php echo e($data->admision->img); ?><?php endif; ?>" name="imglogowm">
</form>
<script>
    const btnAgregar = document.querySelector('.agregador');
    const formList = document.querySelector('.form-list');
    const inputModal = document.querySelector('#menu1');
    const btnGuardar = document.querySelector('.btn-guardar');
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Leo\Desktop\exphadiss\resources\views/menuwm.blade.php ENDPATH**/ ?>