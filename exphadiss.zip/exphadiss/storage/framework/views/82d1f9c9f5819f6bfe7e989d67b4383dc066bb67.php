
<?php $__env->startSection('content'); ?>
                    <div class="card">
                        <form method="post">
                            <div class="card-body p-1">
                                <h4 class="text-inherit">Anuncios</h4>
                                <?php echo csrf_field(); ?>
                                <button class="button_editar button-right" type="submit">Guardar</button>
                                <hr class="mt-2 mb-2">
                            <div class="container-fluid">
                                    <div class="row">
                                        <div class="col-lg-6 mb-4">
                                            <div class="card h-100 p-1 shadow">
                                                <div class="form-group">
                                                    <label class="control-label">Sub Titulo 1</label>
                                                    <input  <?php if($data && $data->sub_title): ?> value="<?php echo e($data->sub_title); ?>" <?php endif; ?> type="text" class="form-control" id="sub_titulo_1" name="sub_titulo_1" placeholder="">
                                                </div>
                                                <hr>
                                                <div class="form-group mt-1">
                                                    <label class="control-label">Sub Titulo 2</label>
                                                    <input  <?php if($data && $data->sub_title_2): ?> value="<?php echo e($data->sub_title_2); ?>" <?php endif; ?> type="text" class="form-control" id="sub_titulo_2" name="sub_titulo_2" placeholder="">
                                                </div>
                                                <hr>
                                                <div class="form-group mt-1">
                                                    <label class="control-label">Contenido</label>
                                                    <textarea class="form-control" id="contenido" name="contenido" rows="8"><?php if($data && $data->description): ?><?php echo e($data->description); ?><?php endif; ?></textarea>
                                                </div>
                                                <hr>
                                                <div class="form-group mt-1">
                                                    <div class="content-buttons-general-text mb-1">
                                                        <h4 class="text-inherit">Boton</h4>
                                                        <div class="button-right-2">
                                                            <h4>Visible</h4>
                                                            <div class="switch">
                                                                <input type="checkbox" <?php if($data): ?> <?php if($data->boton->visible): ?> checked <?php endif; ?> <?php endif; ?> value="visi_anun" name="visi_anun" />
                                                                <div></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <input type="text" class="form-control" value="<?php if($data): ?><?php echo e($data->boton->nombre); ?><?php endif; ?>" id="name_boton_anun" name="name_boton_anun">
                                                    Link
                                                    <input type="text" class="form-control" value="<?php if($data): ?><?php echo e($data->boton->link); ?><?php endif; ?>" id="link_anun" name="link_anun">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 mb-4">
                                            <div class="card h-100 p-1 shadow">
                                                    <label class="control-label">Imagen</label></br>
                                                        <!--<input type="file" class="form-control" id="imagen" name="imagen" placeholder="">-->
                                                    <img data-name="imagenanuncios" class="bc-content-img2 cursor-pointer hero__cta img-fluid-2 rounded-top" name="imagenanuncios" src="<?php if($data): ?><?php echo e($data->img_anuncios->img); ?><?php endif; ?>">

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <input type="hidden" value="<?php if($data): ?><?php echo e($data->img_anuncios->img); ?><?php endif; ?>" class="form-control" id="imagenanuncios" name="imagenanuncios">
                        </form>
                    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Leo\Desktop\exphadiss\resources\views/anuncioswp.blade.php ENDPATH**/ ?>