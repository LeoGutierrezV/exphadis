<?php
$time_banner = $time*1000;
?>

<!DOCTYPE html>
<html lang="es" class="js">
<head>
<meta charset="utf-8">

<meta name="viewport" content="width=device-width, initial-scale=1" />

<meta http-equiv="X-UA-Compatible" content="IE=edge" />

<title>Colegio Exphadis - José Gálvez</title>

<meta name="description" content="Institución Educativa Particular Colegio Exphadis, ubicada en Av. Mariam Quimper 897 - Altura del paradero 5 de la Av. Lima. - José Gálvez - Villa María del Triunfo. Lima, Perú. Educación con valores y tecnología para un Perú con futuro." />

<meta name="keywords" content="colegio exphadis,colegio exphadis jose galvez,colegio en jose galvez,colegio villa maria del triunfo,colegio en villa maria del triunfo,colegio en vmt,colegio vmt" />

<meta name="author" content="Colegio Exphadis - José Gálvez" />

<link rel="shortcut icon" type="image/ico" href="https://firebasestorage.googleapis.com/v0/b/exphadisprueba2022.appspot.com/o/292109841_401005132047260_5062265451483405999_n%20(2).ico?alt=media&token=16f7b3e2-7740-4653-a37e-56682811d75c" />

<link rel="canonical" href="https://colegioexphadis.com.pe/" />


<meta property="og:locale" content="es-ES" />

<meta property="og:title" content="Colegio Exphadis - José Gálvez" />

<meta property="og:description" content="Institución Educativa Particular Colegio Exphadis, ubicada en Av. Mariam Quimper 897 - Altura del paradero 5 de la Av. Lima. - José Gálvez - Villa María del Triunfo. Lima, Perú. Educación con valores y tecnología para un Perú con futuro." />

<meta property="og:url" content="https://colegioexphadis.com.pe/" />

<meta property="og:site_name" content="Colegio Exphadis - José Gálvez" />

<meta property="og:image" content="" />

<meta property="og:image:width" content="" />
<meta property="og:image:height" content="" />
<!-- Stylesheet================================================== -->
<link rel="stylesheet" type="text/css" href="/css/style-general.css" />
<link rel="stylesheet" type="text/css" href="/css/style.css" />
<link rel="shortcut icon" type="ico/icon" href="" />
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
<link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" />
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-63357240-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-63357240-1');
</script>
</head>
<body>
<!--PANTALLA DE CARGA-->
  <div class="preloader">
		<div class="loader-container">
				<img loading="lazy" src="https://firebasestorage.googleapis.com/v0/b/exphadisprueba2022.appspot.com/o/292109841_401005132047260_5062265451483405999_n.jpg?alt=media&token=17553484-3623-4a1f-9bee-6933b9851257" class="shadow">
    </div>
	</div>
<!--FIN DE PANTALLA DE CARGA-->


  <nav id="menu" class="navbar navbar-default navbar-fixed-top on">
    <?php if($admin->horario->visible): ?>
      <div class="header_top_area">
        <div class="container">
          <div class="row">
            <div class="col-md-6 col-sm-6">
              <p class="text-center"><?php if($horarios): ?><?php echo e($horarios->content_optional); ?> <?php endif; ?></p>
            </div>
            <div class="col-md-6 col-sm-6 intranet">
              <a href="https://intranet.colegioexphadis.com.pe/"><i class="fa fa-user"></i> <p>Intranet</p></a>
            </div>
          </div>
        </div>
      </div>
    <?php endif; ?>
    <?php if($admin->menu->visible): ?>
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"> <span class="sr-only"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
        <a href="/"><img loading="lazy" class="img-header-exphadis" src="<?php if($menu): ?><?php echo e($menu->inicio->img); ?> <?php endif; ?>"></a></div>
      <div class="collapse navbar-collapse text-center" id="bs-example-navbar-collapse-1">
        <ul class="nav navbar-nav navbar-right">
          <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($link->visible==true): ?>
              <li><a href="<?php echo e($link->url); ?>" class="page-scroll active"><?php echo e($link->nombre); ?></a></li>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </ul>
      </div>
    </div>
    <?php endif; ?>
  </nav>
<!--<div class="space_nav"></div>-->
<?php if($admin->banner->visible): ?>

  <div class="box-slider">


    <div class="swiper mySwiper background-white" style="--swiper-navigation-color: #fff; --swiper-pagination-color: #fff">
      <div class="swiper-wrapper">
      <?php $__currentLoopData = $banner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ban): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="swiper-slide swiper-lazy" loading="lazy" style="background-image:url('<?php echo e($ban->img); ?>');">
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <!--<div class="swiper-pagination"></div>
      <div class="swiper-button-next"></div>
      <div class="swiper-button-prev"></div>-->
    </div>

  </div>
<?php endif; ?>

<!--Banner 1-->
<?php if($admin->nosotros->visible): ?>
<section id="about-section">
  <div class="container">
    <div class="content-white-texto-exphadis">
    <div class="section-title">
      <h2 class="fw-8 text-center"><?php if($nosotros): ?><?php echo e($nosotros->title_seccion); ?> <?php endif; ?></h2>
      <hr>
    </div>
    <div class="row flex-center padding_content_nosotros">
      <div class="col-lg-6 col-md-5 order-md-1" style="position:relative;">
        <img loading="lazy" class="shadow img-responsive" style="" src="<?php if($nosotros): ?><?php echo e($nosotros->content_optional); ?> <?php endif; ?>" alt="Nosotros Exphadis" />
      </div>
      <div class="col-md-6 col-lg-6">
        <h3 class="fw-bold color-text-exphadis text-align-left"><?php if($nosotros): ?><?php echo e($nosotros->sub_title); ?> <?php endif; ?><br><h2 class="text-align-left"><span class="fw-bold"><?php if($nosotros): ?><?php echo e($nosotros->sub_title_2); ?> <?php endif; ?></span></h2></h3>
        <p class="mt-3 mb-3"><?php if($nosotros): ?><?php echo e($nosotros->description); ?> <?php endif; ?></p>
      </div>
    </div>
    </div>
  </div>
</section>
<?php endif; ?>
<?php if($admin->pilares->visible): ?>
<section class="pb-6 banner1">
  <div class="container">
    <div class="section-title">
      <h3 class="text-center"><strong class="color-text-exphadis fw-8"><?php if($title): ?><?php echo e($title); ?> <?php endif; ?></strong><br><?php if($subtitle): ?><?php echo e($subtitle); ?> <?php endif; ?></h3>
      <hr>
    </div>
    <div class="wrapper-pilar">
      <div class="line"></div>

      <?php $__currentLoopData = $pilar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $pilar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($key!='pilar'): ?>
      <?php if($pilar->visible): ?>
      <div class="pilar <?php echo e($pilar->clase); ?>">
        <div class="container-cubo">
          <div class="cubo">
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <img loading="lazy" src="<?php echo e($pilar->img); ?>">
          </div>
        </div>
        <span class="dot"></span>
        <h3><?php echo e($pilar->titulo); ?></h3>
        <p><?php echo e($pilar->descripcion); ?></p>
      </div>
      <?php endif; ?>
      <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
  <!-- end of .container-->
</section>
<?php endif; ?>
<?php if($admin->propuesta->visible): ?>
<div id="services-section"></div>
<!--============PROPUESTAS============-->
<!-- About Section -->
<div class="padding-content-min">
<div class="bg"></div>
<div class="bg bg2"></div>
<div class="bg bg3"></div>
  <div class="container">
    <div class="section-title">
      <h2 class="fw-8 color-white text-center"><?php echo e($propuesta->propuesta->titulo); ?></h2>
      <hr class="background-white">
    </div>
    <div class="container-fluid-2">
      <div class="row-2">
        <?php $__currentLoopData = $propuesta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $prop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($key!='propuesta'): ?>
        <?php if($prop->visible): ?>
        <div class="rs_order_2 rs_order_3 p-1"><!--rs_order_1 rs_order_4-->
          <div class="card2 h-100 p-1 shadow_2">
            <div class="card-body2">
              <img loading="lazy" src="<?php echo e($prop->img); ?>" class="img-responsive-2 rounded-top" alt="colegioexphadis">
              <div class="text-propuesta">
                <h4 class="fw-8"><?php echo e($prop->titulo); ?></h4>
                <p class="responsive-text-p fw-bold"><?php echo e($prop->descripcion); ?></p>
              </div>
            </div>

          </div>
        </div>
        <?php endif; ?>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </div>
</div>
<?php endif; ?>
<?php if($admin->galeria->visible): ?>
<div id="works-section">
    <div class="section-title">
      <h2 class="fw-8 titles-exphadis text-center"><?php if($titulo): ?><?php echo e($titulo); ?> <?php endif; ?></h2>
      <hr>
      <div class="clearfix"></div>
    </div>
    <section style="
    width: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;">
        <ul>
            <li class="list active" data-filter="all">Todos</li>
            <?php $__currentLoopData = $galeria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($gal->visible): ?>
            <li class="list" data-filter=".<?php echo e(str_replace(' ','-',$gal->titulo)); ?>"><?php echo e($gal->titulo); ?></li>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <div class="product">
            <?php $__currentLoopData = $galeria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($gal->visible): ?>
            <?php $__currentLoopData = $gal->imgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="itemBox bg2" data-item=".<?php echo e(str_replace(' ','-',$gal->titulo)); ?>">
              <a class="bg2">
                <img loading="lazy" class="bg2" src="<?php echo e($img); ?>" alt="" />
              </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </section>
</div>
<?php endif; ?>
<!--<section class="modal ">
  <div class="modal__container">
      <img src="" class="modal__img">
      <i class="modal__close fa fa-window-close"></i>
      <a class="btn btn-default" href="https://www.facebook.com/exphadis/photos/?ref=page_internal">Ver mas fotos</a>
  </div>
</section>-->
<?php if($admin->anuncios->visible): ?>
<section class="pb-6 background-white-2">
  <div class="banner-efect">
    <div class="banner-efect-2">
  <div class="container">
      <div class="row flex-center padding-content">

        <div class="col-md-6 col-lg-6" style="margin-bottom: 2rem;">
          <h3 class="fw-bold color-text-exphadis text-align-left text-white"><?php if($anuncioswp_subtitle): ?><?php echo e($anuncioswp_subtitle); ?> <?php endif; ?><br><h2 class="text-align-left text-white"><span class="fw-bold"><?php if($anuncioswp_subtitle_2): ?><?php echo e($anuncioswp_subtitle_2); ?> <?php endif; ?></span></h2></h3>
          <p class="mt-3 mb-3 text-white fw-bold"><?php if($anuncioswp_cont): ?><?php echo e($anuncioswp_cont); ?> <?php endif; ?></p>
          <?php if($anuncios_options->boton->visible): ?>
          <a class="btn-portafolio-2" href="<?php if($anuncios_options): ?><?php echo e($anuncios_options->boton->link); ?> <?php endif; ?>"><?php if($anuncios_options): ?><?php echo e($anuncios_options->boton->nombre); ?> <?php endif; ?></a>
          <?php endif; ?>
        </div>
        <div class="col-lg-6 col-md-5 order-md-1" style="position:relative;">
          <img loading="lazy" class="shadow img-responsive" src="<?php if($anuncios_options): ?><?php echo e($anuncios_options->img_anuncios->img); ?> <?php endif; ?>" alt="<?php if($anuncioswp_cont): ?><?php echo e($anuncioswp_cont); ?> <?php endif; ?>" />
        </div>

      </div>
    </div>
  </div>
  <!-- end of .container-->
</section>
<?php endif; ?>
<!--================Contact Section================ -->
<div class="w-100 p-0 text-center background-white">
<?php if($admin->googlemaps->visible): ?>
<iframe loading="lazy" src="<?php if($googlemaps): ?><?php echo e($googlemaps->content_optional); ?> <?php endif; ?>" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
<?php endif; ?>
<!-- Footer Start -->
<?php if($admin->contacto->visible): ?>
<footer>
  <div id="contact-section">
    <div class="row-footer">

      <div class="col-footer">
        <h3>Niveles:<div class="underline"><span></span></div></h3>
        <?php if($contacto): ?>
        <?php if($key!='contacto'): ?>
        <p><?php echo e($contacto->niveles->nivel1); ?></p>
        <p><?php echo e($contacto->niveles->nivel2); ?></p>
        <p><?php echo e($contacto->niveles->nivel3); ?></p>
        <?php endif; ?>
        <?php endif; ?>
      </div>
      <div class="col-footer">
        <h3>Visítanos:<div class="underline"><span></span></div></h3>
        <?php if($contacto): ?>
        <?php if($key!='contacto'): ?>
        <p><i class="fas fa-map-marker-alt"></i><?php echo e($contacto->visitanos->ubicacion); ?></p>
        <?php endif; ?>
        <?php endif; ?>

      </div>
      <div class="col-footer">
        <h3>Telefónica:<div class="underline"><span></span></div></h3>
        <?php if($contacto): ?>
        <?php if($key!='contacto'): ?>
        <p><i class="fas fa-phone-alt"></i><?php echo e($contacto->telefonica->num1); ?></p>
        <p><i class="fas fa-phone-alt"></i><?php echo e($contacto->telefonica->num2); ?></p>
        <?php endif; ?>
        <?php endif; ?>


      </div>

    </div>
  </div>
</footer>
<?php endif; ?>
</div>
<!-- Footer End -->
<!--================CONVERSEMOS===============-->
<?php if(count($redes)>0): ?>
<div id="social-icons">
  <div class="text-right">
      <ul class="social-icons">
          <div class="social-btn-container">


            <?php $__currentLoopData = $redes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $red): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($red->bool): ?>
            <span class="<?php echo e($red->clase); ?>">
                <a href="<?php echo e($red->link_redes); ?>" class="<?php echo e($red->clase1); ?>">
                  <i class="<?php echo e($red->clase2); ?>"></i>
                </a>
            </span>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </div>
      </ul>
  </div>
</div>
<?php endif; ?>

<div id="footer">
  <div class="container">
    <p class="text-center">Copyright &copy; Diseñado por colegioexphadis.pe<a href="" rel="nofollow"></a></p>
  </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script>
  const preloader = document.querySelector(".preloader");

  window.addEventListener("load", () =>{
    preloader.style.display= "none";
  })
</script>
<script type="text/javascript" src="js/jquery.isotope.js"></script>
<script type="text/javascript" src="js/main.js"></script>
<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
<script>
var swiper = new Swiper(".mySwiper", {
        /*spaceBetween: 30,*/
        centeredSlides: true,
        autoplay: {
          delay: <?= $time_banner?>,
          disableOnInteraction: false,
        },
        pagination: {
          el: ".swiper-pagination",
          clickable: true,
        },
        navigation: {
          nextEl: ".swiper-button-next",
          prevEl: ".swiper-button-prev",
        },
      });
</script>
<script>
let list = document.querySelectorAll('.list');
let itemBox = document.querySelectorAll('.itemBox');

for(let i = 0; i<list.length; i++){
    list[i].addEventListener('click', function(){
        for(let j = 0; j<list.length; j++){
            list[j].classList.remove('active');
        }
        this.classList.add('active');

        let dataFilter = this.getAttribute('data-filter');

        for(let k = 0; k<itemBox.length; k++){
            itemBox[k].classList.remove('active');
            itemBox[k].classList.add('hide');

        if(itemBox[k].getAttribute('data-item') == dataFilter || dataFilter == "all"){
            itemBox[k].classList.remove('hide');
            itemBox[k].classList.add('active');
        }
    }
    })
}
</script>
</body>
</html>
<?php /**PATH C:\Users\Leo\Desktop\exphadiss\resources\views/index.blade.php ENDPATH**/ ?>