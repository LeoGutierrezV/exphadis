<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="author" content="">
<title>Exphadis</title>
<meta name="description" content="">
<meta name="author" content="">
<!-- Stylesheet================================================== -->
<link rel="stylesheet" type="text/css"  href="css/style-general.css">
<link rel="stylesheet" type="text/css"  href="css/style.css">
<!--<link rel="stylesheet" type="text/css" href="css/prettyPhoto.css">-->
<link rel="shortcut icon" type="ico/icon" href="https://firebasestorage.googleapis.com/v0/b/exphadisprueba2022.appspot.com/o/292109841_401005132047260_5062265451483405999_n%20(2).ico?alt=media&token=16f7b3e2-7740-4653-a37e-56682811d75c">
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
<link href='http://fonts.googleapis.com/css?family=Lato:400,700,900,300' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800,600,300' rel='stylesheet' type='text/css'>

</head>
<body>
 <form action="mail.php" method="post">
    <input type="text" name="name">
    <input type="text" name="email">
    <input type="text" name="subject">
    <textarea name="message" id="" cols="30" rows="10"></textarea>
    <button type="submit">Enviar</button>
 </form>
</body>
</html><?php /**PATH C:\Users\Leo\Desktop\exphadiss\resources\views/gracias.blade.php ENDPATH**/ ?>