
<?php $__env->startSection('content'); ?>
 
<div class="card">
    <div class="card-body p-4">
        <div class="container-fluid">
            <div class="row">

                <div class="col-xxl-3 col-xl-4 col-lg-6 col-12 mb-4 images">
                    <div class="card h-100 image-box">
                        <div class="mostrar-imagen-exphadis"></div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Leo\Desktop\exphadiss\resources\views/cargarimagen.blade.php ENDPATH**/ ?>